import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* Standalone output is only needed for the local sandbox's custom start
     script — Vercel builds standard output. */
  output: process.env.VERCEL ? undefined : "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  images: {
    qualities: [75, 80, 85, 90],
  },
};

export default nextConfig;
