"use client";

import Image from "next/image";
import { ArrowUpRight, NotebookPen } from "lucide-react";
import { projectsBlurb, profile } from "@/lib/data";
import { SectionHeading } from "./section-heading";
import { PaintButton } from "./paint-button";
import { PaintedIcon } from "./painted-icon";
import { Reveal } from "./reveal";

export function Projects() {
  return (
    <section
      id="projects"
      aria-label="Projects"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          index="05"
          eyebrow="Projects"
          title={projectsBlurb.heading}
        />

        <Reveal delay={0.12}>
          <div className="paint-dab painted-panel relative mt-12 overflow-hidden rounded-xl" style={{ "--dab": "#7ac4ce" } as React.CSSProperties}>
            {/* The pool painting */}
            <div className="absolute inset-0" aria-hidden="true">
              <Image
                src="/images/pool-strip.jpg"
                alt=""
                fill
                quality={85}
                sizes="(max-width: 1280px) 100vw, 1216px"
                className="object-cover object-bottom opacity-45"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-canvas via-canvas/72 to-canvas/35" />
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_90%_80%_at_50%_0%,transparent_20%,rgba(16,27,14,0.6)_100%)]" />
            </div>

            <div className="relative flex min-h-[440px] flex-col items-start justify-between gap-10 p-7 sm:p-12 lg:flex-row lg:items-end">
              <div className="max-w-2xl">
                <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.3em] text-aqua">
                  <PaintedIcon icon={NotebookPen} className="text-aqua" />
                  Web3 &amp; AI — the full log
                </p>
                <p className="font-painterly-gentle mt-5 font-display text-2xl italic leading-snug text-haze/95 sm:text-[28px]">
                  {projectsBlurb.copy}
                </p>
                <p className="mt-6 max-w-xl text-[13.5px] leading-relaxed text-ink-dim">
                  {projectsBlurb.note}
                </p>
              </div>

              <div className="shrink-0">
                <PaintButton
                  href={profile.projectsUrl}
                  external
                  ariaLabel="Open the project log on Notion (opens in a new tab)"
                >
                  {projectsBlurb.cta}
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </PaintButton>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
