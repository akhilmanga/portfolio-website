"use client";

import { useState, type FormEvent } from "react";
import {
  Mail,
  Twitter,
  Linkedin,
  Github,
  Send,
  Link2,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { profile } from "@/lib/data";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SectionHeading } from "./section-heading";
import { Reveal } from "./reveal";
import { useToast } from "@/hooks/use-toast";

const channels = [
  { label: "X (Twitter)", handle: "@akhil_manga", url: "https://x.com/akhil_manga", icon: Twitter },
  { label: "LinkedIn", handle: "in/akhilmanga", url: "https://www.linkedin.com/in/akhilmanga/", icon: Linkedin },
  { label: "GitHub", handle: "akhilmanga", url: "https://github.com/akhilmanga", icon: Github },
  { label: "Linktree", handle: "linktr.ee/akhilmanga", url: "https://linktr.ee/akhilmanga", icon: Link2 },
];

type FormStatus = "idle" | "submitting" | "success";

export function Contact() {
  const { toast } = useToast();
  const [status, setStatus] = useState<FormStatus>("idle");
  const [interest, setInterest] = useState("Role opportunity");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    const payload = {
      name: String(data.get("name") ?? "").trim(),
      email: String(data.get("email") ?? "").trim(),
      org: String(data.get("org") ?? "").trim(),
      interest,
      message: String(data.get("message") ?? "").trim(),
    };

    if (payload.name.length < 2 || payload.message.length < 10) {
      toast({
        title: "Almost there",
        description: "Please add your name and a message (10+ characters).",
        variant: "destructive",
      });
      return;
    }

    setStatus("submitting");
    await new Promise((r) => setTimeout(r, 550));

    /* Compose the note in the visitor's own mail client — the site stays
       fully static, free to host anywhere (Vercel) with no database. */
    const subject = `[Portfolio] ${payload.interest} — ${payload.name}`;
    const lines = [
      `Name: ${payload.name}`,
      `Email: ${payload.email}`,
      ...(payload.org ? [`Organization: ${payload.org}`] : []),
      `Topic: ${payload.interest}`,
      "",
      payload.message,
    ];
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(lines.join("\n"))}`;

    setStatus("success");
    form.reset();
    setInterest("Role opportunity");
    window.setTimeout(() => setStatus("idle"), 4500);
    toast({
      title: "Opening your email app",
      description: `The message is ready — just press send. If nothing opened, write to ${profile.email} directly.`,
    });
  }

  return (
    <section
      id="contact"
      aria-label="Contact"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          index="06"
          eyebrow="Contact"
          title={
            <>
              Say <span className="italic text-haze">hello</span>.
            </>
          }
          lead="Hiring for an AI safety role? Recruiting for a fellowship? Or just curious about the field — write a few lines."
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-[1.25fr_1fr]">
          {/* Form */}
          <Reveal delay={0.08}>
            <form
              onSubmit={onSubmit}
              className="paint-dab painted-panel rounded-xl p-6 sm:p-8"
              style={{ "--dab": "#8a9a3a" } as React.CSSProperties}
              aria-label="Contact form"
            >
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-[13px] text-ink">
                    Name <span className="text-rust">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    required
                    minLength={2}
                    placeholder="Ada Lovelace"
                    className="h-11 rounded-md border-cream/12 bg-canvas/60 text-cream placeholder:text-ink-dim/50 focus-visible:ring-moss/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[13px] text-ink">
                    Email <span className="text-rust">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="you@org.org"
                    className="h-11 rounded-md border-cream/12 bg-canvas/60 text-cream placeholder:text-ink-dim/50 focus-visible:ring-moss/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="org" className="text-[13px] text-ink">
                    Organization <span className="text-ink-dim/60">(optional)</span>
                  </Label>
                  <Input
                    id="org"
                    name="org"
                    placeholder="Anthropic, MATS, ..."
                    className="h-11 rounded-md border-cream/12 bg-canvas/60 text-cream placeholder:text-ink-dim/50 focus-visible:ring-moss/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="interest" className="text-[13px] text-ink">
                    This is about
                  </Label>
                  <Select value={interest} onValueChange={setInterest}>
                    <SelectTrigger
                      id="interest"
                      className="h-11 rounded-md border-cream/12 bg-canvas/60 text-cream focus:ring-moss/50"
                    >
                      <SelectValue placeholder="Pick one" />
                    </SelectTrigger>
                    <SelectContent className="border-cream/10 bg-[#141f10] text-cream">
                      <SelectItem value="Role opportunity">
                        Role opportunity
                      </SelectItem>
                      <SelectItem value="Fellowship">Fellowship</SelectItem>
                      <SelectItem value="Collaboration">Collaboration</SelectItem>
                      <SelectItem value="Audit request">Audit request</SelectItem>
                      <SelectItem value="general">Something else</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="message" className="text-[13px] text-ink">
                    Message <span className="text-rust">*</span>
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    minLength={10}
                    rows={5}
                    placeholder="A few lines about what you're working on..."
                    className="min-h-32 rounded-md border-cream/12 bg-canvas/60 text-cream placeholder:text-ink-dim/50 focus-visible:ring-moss/50"
                  />
                </div>
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
                <p className="text-[12px] text-ink-dim">
                  Prefer email?{" "}
                  <a
                    href={`mailto:${profile.email}`}
                    className="text-haze underline-offset-4 hover:underline"
                  >
                    {profile.email}
                  </a>
                </p>
                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="btn-paint inline-flex items-center gap-2.5 px-7 py-3 text-[14.5px] font-semibold tracking-tight text-canvas-deep disabled:opacity-60"
                >
                  <span className="btn-paint-bg" aria-hidden="true" />
                  {status === "submitting" ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      Sending...
                    </>
                  ) : status === "success" ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                      Ready to send
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" aria-hidden="true" />
                      Send message
                    </>
                  )}
                </button>
              </div>
            </form>
          </Reveal>

          {/* Direct channels */}
          <Reveal delay={0.14}>
            <div
              className="paint-dab painted-panel h-full rounded-xl p-6 sm:p-7"
              style={{ "--dab": "#b8a8d0" } as React.CSSProperties}
            >
              <h3 className="font-mono text-[10px] uppercase tracking-[0.3em] text-lavender">
                Elsewhere
              </h3>
              <ul className="mt-5 space-y-2.5">
                <li>
                  <a
                    href={`mailto:${profile.email}`}
                    className="group flex items-center gap-3.5 rounded-lg border border-cream/10 bg-cream/3 p-3.5 transition-all duration-300 hover:border-moss/40 hover:bg-moss/8"
                  >
                    <span className="icon-wiggle grid h-10 w-10 place-items-center rounded-[9px_5px_10px_4px] border border-moss/30 bg-moss/10 text-moss">
                      <Mail className="h-4.5 w-4.5" aria-hidden="true" />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-cream">
                        Email
                      </span>
                      <span className="block truncate text-xs text-ink-dim">
                        {profile.email}
                      </span>
                    </span>
                  </a>
                </li>
                {channels.map((ch) => {
                  const Icon = ch.icon;
                  return (
                    <li key={ch.label}>
                      <a
                        href={ch.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group flex items-center gap-3.5 rounded-lg border border-cream/10 bg-cream/3 p-3.5 transition-all duration-300 hover:border-cream/25 hover:bg-cream/6"
                      >
                        <span className="icon-wiggle grid h-10 w-10 place-items-center rounded-[9px_5px_10px_4px] border border-cream/15 bg-cream/5 text-ink/80 transition-colors group-hover:text-cream">
                          <Icon className="h-4.5 w-4.5" aria-hidden="true" />
                        </span>
                        <span className="min-w-0">
                          <span className="block text-sm font-semibold text-cream">
                            {ch.label}
                          </span>
                          <span className="block truncate text-xs text-ink-dim">
                            {ch.handle}
                          </span>
                        </span>
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
