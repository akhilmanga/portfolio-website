"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";

/**
 * The section opener — a hand-painted branch grows across the page
 * while loose leaves shake free and flutter down into the section
 * below, like a painter clearing the canvas for the next study.
 */

type Tone = "fern" | "rust" | "aqua";

const TONES: Record<
  Tone,
  {
    stem: string;
    stemLight: string;
    brushA: string;
    brushB: string;
    leaves: string[];
    flower: string;
    faller: string;
  }
> = {
  fern: {
    stem: "#3a5224",
    stemLight: "#8a9a3a",
    brushA: "#5a6e2e",
    brushB: "#8a9a3a",
    leaves: ["#2e4a1e", "#4a6224", "#5a6e2e", "#3a5224", "#6b7a30", "#8a9a3a"],
    flower: "#d8a0c0",
    faller: "#5a6e2e",
  },
  rust: {
    stem: "#6e3a26",
    stemLight: "#c4523f",
    brushA: "#a85e42",
    brushB: "#c4523f",
    leaves: ["#7a3a28", "#a85e42", "#c4523f", "#8f4632", "#b85a3a", "#d0644f"],
    flower: "#e8d9a8",
    faller: "#a85e42",
  },
  aqua: {
    stem: "#2e5a56",
    stemLight: "#7ac4ce",
    brushA: "#3e8898",
    brushB: "#7ac4ce",
    leaves: ["#2e5a4e", "#3e8898", "#7ac4ce", "#35707e", "#4a9aa8", "#8fd0d8"],
    flower: "#b8a8d0",
    faller: "#3e8898",
  },
};

const BRANCH_D =
  "M 14 58 C 170 28, 330 68, 500 46 C 670 24, 830 64, 986 34";
const TWIG_D = "M 250 42 C 340 14, 430 12, 525 32";

const BRANCH_FRACS = [
  0.06, 0.13, 0.21, 0.29, 0.37, 0.45, 0.53, 0.61, 0.69, 0.77, 0.85, 0.93,
];

/* Leaves that detach and flutter down into the next section */
const FALLERS = [
  { frac: 0.16, dx: 26, rot: 220, len: 40, delay: 1.35 },
  { frac: 0.44, dx: -34, rot: -240, len: 46, delay: 1.85 },
  { frac: 0.68, dx: 22, rot: 200, len: 38, delay: 2.35 },
  { frac: 0.88, dx: -20, rot: -190, len: 42, delay: 2.8 },
];

type LeafT = {
  x: number;
  y: number;
  angle: number;
  side: number;
  len: number;
  wid: number;
  color: string;
  frac: number;
};

function leafPath(len: number, w: number) {
  return `M 0 0 C ${len * 0.28} ${-w}, ${len * 0.78} ${-w * 0.72}, ${len} 0 C ${
    len * 0.78
  } ${w * 0.55}, ${len * 0.28} ${w * 0.66}, 0 0 Z`;
}

export function BranchDivider({
  className = "",
  tone = "fern",
}: {
  className?: string;
  tone?: Tone;
}) {
  const reduce = useReducedMotion();
  const rootRef = useRef<HTMLDivElement>(null);
  const inView = useInView(rootRef, { once: true, margin: "-30px" });
  const branchRef = useRef<SVGPathElement>(null);
  const [leaves, setLeaves] = useState<LeafT[]>([]);
  const [fallers, setFallers] = useState<{ x: number; y: number }[]>([]);
  const [flowerPts, setFlowerPts] = useState<
    { x: number; y: number }[]
  >([
    { x: 300, y: 40 },
    { x: 820, y: 42 },
  ]);

  const t = TONES[tone];

  useEffect(() => {
    const el = branchRef.current;
    if (!el) return;
    try {
      const total = el.getTotalLength();
      const ls: LeafT[] = BRANCH_FRACS.map((frac, i) => {
        const p = el.getPointAtLength(total * frac);
        const p2 = el.getPointAtLength(Math.min(total, total * frac + 6));
        const angle = (Math.atan2(p2.y - p.y, p2.x - p.x) * 180) / Math.PI;
        const len = 52 - Math.abs(0.5 - frac) * 22 + (i % 3) * 5;
        return {
          x: p.x,
          y: p.y,
          angle,
          side: i % 2 === 0 ? 1 : -1,
          len,
          wid: len * 0.32,
          color: t.leaves[i % t.leaves.length],
          frac,
        };
      });
      setLeaves(ls);
      setFallers(
        FALLERS.map((f) => {
          const p = el.getPointAtLength(total * f.frac);
          return { x: p.x, y: p.y };
        })
      );
      setFlowerPts(
        [0.3, 0.82].map((frac) => {
          const p = el.getPointAtLength(total * frac);
          return { x: p.x, y: p.y };
        })
      );
    } catch {
      /* measurement unavailable — branch still renders */
    }
  }, [t]);

  return (
    <motion.div
      ref={rootRef}
      aria-hidden="true"
      className={`pointer-events-none relative mx-auto -my-6 h-28 w-full max-w-5xl sm:-my-8 sm:h-36 ${className}`}
      initial={false}
    >
      {/* soft mist glow behind the branch */}
      <div
        className="animate-mist absolute left-1/2 top-0 h-24 w-3/4 -translate-x-1/2 rounded-full blur-[70px]"
        style={{ background: `${t.stemLight}14` }}
      />

      <svg
        viewBox="0 0 1000 190"
        preserveAspectRatio="xMidYMid meet"
        fill="none"
        className="h-full w-full"
      >
        {/* invisible measurement path */}
        <path
          ref={branchRef}
          d={BRANCH_D}
          stroke="none"
          fill="none"
          opacity="0"
        />

        {/* main branch */}
        <motion.path
          d={BRANCH_D}
          stroke={t.stem}
          strokeWidth="6.5"
          strokeLinecap="round"
          initial={reduce ? false : { pathLength: 0 }}
          animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.6, ease: [0.65, 0, 0.35, 1] }
          }
        />
        <motion.path
          d={BRANCH_D}
          stroke={t.stemLight}
          strokeWidth="2"
          strokeLinecap="round"
          opacity="0.85"
          initial={reduce ? false : { pathLength: 0 }}
          animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.3, delay: 0.25, ease: [0.65, 0, 0.35, 1] }
          }
        />
        {/* offshoot twig */}
        <motion.path
          d={TWIG_D}
          stroke={t.stem}
          strokeWidth="3.5"
          strokeLinecap="round"
          initial={reduce ? false : { pathLength: 0 }}
          animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 0.9, delay: 0.75, ease: "easeOut" }
          }
        />

        {/* sprouting leaves */}
        {leaves.map((leaf, i) => (
          <g
            key={i}
            transform={`translate(${leaf.x} ${leaf.y}) rotate(${
              leaf.angle + leaf.side * 52
            }) scale(1 ${leaf.side})`}
          >
            <motion.path
              d={leafPath(leaf.len, leaf.wid)}
              fill={leaf.color}
              stroke="#141f10"
              strokeWidth="1.2"
              initial={reduce ? false : { scale: 0, opacity: 0 }}
              animate={
                inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }
              }
              transition={
                reduce
                  ? { duration: 0 }
                  : {
                      delay: 0.35 + leaf.frac * 1.15,
                      type: "spring",
                      stiffness: 170,
                      damping: 13,
                    }
              }
              style={{ transformBox: "fill-box", transformOrigin: "0% 50%" }}
            />
          </g>
        ))}

        {/* a couple of small flowers on the branch */}
        {flowerPts.map((f, i) => (
          <motion.g
            key={`flower-${i}`}
            transform={`translate(${f.x} ${f.y}) scale(${
              i === 0 ? 1 : 0.78
            })`}
            initial={reduce ? false : { scale: 0, opacity: 0 }}
            animate={
              inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    delay: 1.3 + i * 0.3,
                    type: "spring",
                    stiffness: 180,
                    damping: 12,
                  }
            }
            style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
          >
            {[0, 72, 144, 216, 288].map((deg) => {
              const a = ((deg - 90) * Math.PI) / 180;
              return (
                <circle
                  key={deg}
                  cx={Math.cos(a) * 6.5}
                  cy={Math.sin(a) * 6.5}
                  r={4.4}
                  fill={t.flower}
                  stroke="#141f10"
                  strokeWidth="0.9"
                />
              );
            })}
            <circle r={2.8} fill="#f5e6c8" stroke="#141f10" strokeWidth="0.9" />
          </motion.g>
        ))}

        {/* loose leaves fluttering down into the section below */}
        {fallers.map((f, i) => {
          const cfg = FALLERS[i];
          return (
            <motion.g
              key={`faller-${i}`}
              transform={`translate(${f.x} ${f.y})`}
              initial={{ opacity: 0 }}
              animate={
                reduce || !inView
                  ? { opacity: 0 }
                  : {
                      opacity: [0, 1, 0.95, 0],
                      y: [0, 48, 98, 148],
                      x: [0, cfg.dx * 0.7, -cfg.dx * 0.4, cfg.dx],
                      rotate: [0, cfg.rot * 0.45, -cfg.rot * 0.25, cfg.rot],
                    }
              }
              transition={
                reduce
                  ? { duration: 0 }
                  : {
                      duration: 3.4,
                      delay: cfg.delay,
                      times: [0, 0.3, 0.64, 1],
                      ease: "linear",
                    }
              }
              style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
            >
              <path
                d={leafPath(cfg.len, cfg.len * 0.36)}
                fill={i % 2 === 0 ? t.faller : t.leaves[(i + 2) % t.leaves.length]}
                stroke="#141f10"
                strokeWidth="1.1"
                opacity="0.95"
              />
            </motion.g>
          );
        })}

        {/* the original brush swipes settle beneath the branch */}
        <motion.path
          d="M6 152 C 160 140, 300 160, 470 148 C 640 137, 780 158, 994 144"
          stroke={t.brushA}
          strokeWidth="6"
          strokeLinecap="round"
          initial={reduce ? false : { pathLength: 0, opacity: 0 }}
          animate={
            inView || reduce ? { pathLength: 1, opacity: 0.55 } : { pathLength: 0, opacity: 0 }
          }
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.4, delay: 0.3, ease: [0.6, 0, 0.3, 1] }
          }
        />
        <motion.path
          d="M40 146 C 220 156, 420 136, 610 150 C 760 160, 880 142, 970 150"
          stroke={t.brushB}
          strokeWidth="2.5"
          strokeLinecap="round"
          initial={reduce ? false : { pathLength: 0, opacity: 0 }}
          animate={
            inView || reduce ? { pathLength: 1, opacity: 0.4 } : { pathLength: 0, opacity: 0 }
          }
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.5, delay: 0.55, ease: [0.6, 0, 0.3, 1] }
          }
        />
      </svg>
    </motion.div>
  );
}
