import type { ReactNode } from "react";

type Variant = "cream" | "rust" | "outline";

const variantClasses: Record<Variant, string> = {
  cream: "text-canvas-deep",
  rust: "text-daisy",
  outline: "text-cream",
};

const variantFilter: Record<Variant, string> = {
  cream: "",
  rust: "btn-paint-rust",
  outline: "btn-paint-outline",
};

export function PaintButton({
  href,
  onClick,
  children,
  variant = "cream",
  external = false,
  className = "",
  ariaLabel,
}: {
  href?: string;
  onClick?: () => void;
  children: ReactNode;
  variant?: Variant;
  external?: boolean;
  className?: string;
  ariaLabel?: string;
}) {
  const cls = `btn-paint ${variantFilter[variant]} inline-flex select-none items-center justify-center gap-2.5 px-7 py-3.5 text-[15px] font-semibold tracking-tight ${variantClasses[variant]} ${className}`;

  if (onClick) {
    return (
      <button type="button" onClick={onClick} aria-label={ariaLabel} className={cls}>
        <span className="btn-paint-bg" aria-hidden="true" />
        {children}
      </button>
    );
  }

  return (
    <a
      href={href}
      aria-label={ariaLabel}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      className={cls}
    >
      <span className="btn-paint-bg" aria-hidden="true" />
      {children}
    </a>
  );
}
