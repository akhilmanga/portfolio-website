"use client";

import { OilSignature } from "./oil-signature";

/**
 * The bottom of the site is a showcase for one thing only —
 * the name, painted in oil. No links, no meta, no small print.
 */
export function Footer() {
  return (
    <footer className="footer-ground relative mt-auto overflow-hidden">
      {/* painted vignette at the top edge */}
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-canvas/80 to-transparent"
      />
      {/* drifting mist */}
      <div
        aria-hidden="true"
        className="animate-mist absolute left-1/2 top-[38%] h-[26%] w-[70%] -translate-x-1/2 rounded-full bg-moss/6 blur-[110px]"
      />

      <div className="relative z-10 mx-auto flex min-h-[52vh] w-full max-w-6xl flex-col items-center justify-center px-6 py-14 sm:min-h-[80vh] sm:px-8 sm:py-28">
        <OilSignature />
      </div>
    </footer>
  );
}
