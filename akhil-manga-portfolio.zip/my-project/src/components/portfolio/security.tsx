"use client";

import { ArrowRight, ArrowUpRight, ShieldCheck, GitBranch } from "lucide-react";
import { cobra, auditRecord, openSource } from "@/lib/data";
import { SectionHeading } from "./section-heading";
import { PaintButton } from "./paint-button";
import { PaintedIcon } from "./painted-icon";
import { Reveal } from "./reveal";

export function Security() {
  return (
    <section
      id="security"
      aria-label="Security research"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          index="03"
          eyebrow="Security Research"
          title={
            <>
              Finding what breaks,{" "}
              <span className="italic text-haze">before it does</span>.
            </>
          }
          lead="Four years of competitive and private Web3 security work — vulnerability research with proof-of-concept exploits, severity-based reporting and remediation."
        />

        {/* Cobra Audits feature */}
        <Reveal delay={0.1}>
          <div
            className="paint-dab painted-panel painted-panel-warm hover-lift relative mt-14 overflow-hidden rounded-xl p-7 sm:p-10"
            style={{ "--dab": "#c4523f" } as React.CSSProperties}
          >
            {/* faint brush glow */}
            <div
              aria-hidden="true"
              className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-rust/12 blur-[90px]"
            />
            <div className="relative grid gap-10 lg:grid-cols-[1.25fr_1fr] lg:gap-12">
              <div>
                <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.3em] text-sienna">
                  <PaintedIcon icon={ShieldCheck} className="text-sienna" />
                  Private audits
                </p>
                <h3 className="font-painterly mt-4 font-display text-4xl font-semibold tracking-tight text-cream sm:text-5xl">
                  Cobra <span className="italic text-haze">Audits</span>
                </h3>
                <p className="mt-5 max-w-xl text-[15.5px] leading-relaxed text-ink/85">
                  {cobra.detail}
                </p>

                {/* process */}
                <ol className="mt-7 flex flex-wrap items-center gap-x-2 gap-y-2">
                  {cobra.process.map((step, i) => {
                    const isReport = step === "Report";
                    return (
                      <li
                        key={step}
                        className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-dim"
                      >
                        {isReport ? (
                          <a
                            href={cobra.reportUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label="Read the Cobra Audits report (opens in a new tab)"
                            className="group/report inline-flex items-center gap-1.5 rounded-[5px_3px_6px_2px] border border-sienna/50 bg-rust/15 px-2.5 py-1.5 text-cream transition-all duration-300 hover:-translate-y-0.5 hover:border-sienna hover:bg-rust/30 hover:shadow-[0_0_20px_rgba(196,82,63,0.28)]"
                          >
                            Report
                            <ArrowUpRight
                              className="h-3 w-3 text-sienna transition-transform duration-300 group-hover/report:-translate-y-0.5 group-hover/report:translate-x-0.5"
                              aria-hidden="true"
                            />
                          </a>
                        ) : (
                          <span className="rounded-[5px_3px_6px_2px] border border-cream/12 bg-canvas/40 px-2.5 py-1.5 text-cream/85">
                            {step}
                          </span>
                        )}
                        {i < cobra.process.length - 1 ? (
                          <ArrowRight
                            className="h-3.5 w-3.5 text-sienna/80"
                            aria-hidden="true"
                          />
                        ) : null}
                      </li>
                    );
                  })}
                </ol>

                <div className="mt-9">
                  <PaintButton
                    href={cobra.url}
                    external
                    variant="rust"
                    ariaLabel="Visit Cobra Audits (opens in a new tab)"
                  >
                    Visit Cobra Audits
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </PaintButton>
                </div>
              </div>

              {/* stacks */}
              <div className="flex flex-col justify-center">
                <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-ink-dim">
                  Stacks covered
                </p>
                <div className="mt-4 flex flex-wrap gap-2.5">
                  {cobra.stacks.map((stack) => (
                    <span
                      key={stack}
                      className="rounded-[7px_4px_8px_3px] border border-sienna/30 bg-rust/10 px-3.5 py-2 font-mono text-[12px] tracking-wide text-cream/90"
                    >
                      {stack}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Record + open source */}
        <div className="mt-8 grid gap-8 lg:grid-cols-[1.35fr_1fr]">
          {/* competitive record */}
          <Reveal delay={0.12}>
            <div className="paint-dab painted-panel h-full rounded-xl p-6 sm:p-8" style={{ "--dab": "#8a9a3a" } as React.CSSProperties}>
              <h3 className="font-mono text-[10px] uppercase tracking-[0.3em] text-moss">
                Competitive record
              </h3>
              <ul className="mt-5 divide-y divide-cream/8">
                {auditRecord.map((record) => (
                  <li key={record.platform}>
                    <a
                      href={record.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center justify-between gap-4 py-4 transition-colors first:pt-0 last:pb-0"
                    >
                      <div className="min-w-0">
                        <p className="flex flex-wrap items-baseline gap-x-2.5">
                          <span className="text-[15.5px] font-semibold text-cream">
                            {record.platform}
                          </span>
                          <span className="font-display text-[14px] italic text-moss transition-colors group-hover:text-haze">
                            {record.highlight}
                          </span>
                        </p>
                        <p className="mt-1 text-[13px] leading-relaxed text-ink-dim">
                          {record.detail}
                        </p>
                      </div>
                      <ArrowUpRight
                        className="h-4.5 w-4.5 shrink-0 text-ink-dim/50 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-cream"
                        aria-hidden="true"
                      />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* open source */}
          <div className="space-y-8">
            {openSource.map((item, i) => (
              <Reveal key={item.title} delay={0.16 + 0.08 * i}>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="paint-dab painted-panel hover-lift group block rounded-xl p-6 sm:p-7"
                  style={
                    {
                      "--dab": i === 0 ? "#b8a8d0" : "#7ac4ce",
                    } as React.CSSProperties
                  }
                >
                  <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.3em] text-ink-dim">
                    <PaintedIcon
                      icon={GitBranch}
                      className={i === 0 ? "text-lavender" : "text-aqua"}
                      delay={0.15 * i}
                    />
                    {item.org}
                  </p>
                  <h4 className="mt-3.5 font-display text-xl font-semibold tracking-tight text-cream">
                    {item.title}
                  </h4>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-ink/80">
                    {item.detail}
                  </p>
                  <p className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-medium text-moss transition-colors group-hover:text-haze">
                    View on GitHub
                    <ArrowUpRight
                      className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                      aria-hidden="true"
                    />
                  </p>
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
