"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, GraduationCap, Wrench } from "lucide-react";
import { experience, training, toolkit } from "@/lib/data";
import { SectionHeading } from "./section-heading";
import { PaintedIcon } from "./painted-icon";
import { Reveal } from "./reveal";

/* One impasto dab color per role, pulled from the painting */
const dabColors = [
  "#8a9a3a",
  "#7ac4ce",
  "#d8a0c0",
  "#a85e42",
  "#b8a8d0",
];

export function Experience() {
  return (
    <section
      id="experience"
      aria-label="Experience"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          index="02"
          eyebrow="Experience"
          title={
            <>
              Where the <span className="italic text-haze">work</span>{" "}
              happened.
            </>
          }
          lead="Community, operations and product — five years of building things that other people could rely on."
        />

        <div className="mt-14 grid gap-12 lg:grid-cols-[1.55fr_1fr] lg:gap-14">
          {/* Timeline */}
          <div className="relative">
            {/* painted spine */}
            <div
              aria-hidden="true"
              className="absolute bottom-6 left-[7px] top-2 w-px bg-gradient-to-b from-moss/50 via-cream/15 to-transparent"
            />
            <ol className="space-y-10">
              {experience.map((item, i) => (
                <li key={`${item.org}-${item.role}`} className="relative pl-10">
                  {/* impasto dab dot pops in like a dab of paint */}
                  <motion.span
                    aria-hidden="true"
                    className="absolute left-0 top-1.5 h-[15px] w-[15px] rounded-[62%_38%_55%_45%] shadow-[0_0_14px_rgba(0,0,0,0.45)]"
                    style={{
                      background: `linear-gradient(135deg, ${dabColors[i % dabColors.length]}, color-mix(in srgb, ${dabColors[i % dabColors.length]} 45%, #f5e6c8))`,
                    }}
                    initial={{ scale: 0, rotate: -30 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true, margin: "-40px" }}
                    transition={{
                      type: "spring",
                      stiffness: 300,
                      damping: 15,
                      delay: 0.2 + i * 0.08,
                    }}
                  />
                  <Reveal delay={0.05 * i}>
                    <div className="group">
                      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                        <h3 className="font-display text-2xl font-semibold tracking-tight text-cream">
                          {item.role}
                          {item.url ? (
                            <a
                              href={item.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="ml-2 inline-flex items-center gap-1 font-sans text-[15px] font-normal text-moss underline decoration-moss/40 underline-offset-4 transition-colors hover:text-cream hover:decoration-cream"
                            >
                              {item.org}
                              <ArrowUpRight
                                className="h-3.5 w-3.5"
                                aria-hidden="true"
                              />
                            </a>
                          ) : (
                            <span className="ml-2 font-sans text-[15px] font-normal text-moss">
                              {item.org}
                            </span>
                          )}
                        </h3>
                        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-dim/85">
                          {item.period}
                        </p>
                      </div>
                      <ul className="mt-3.5 max-w-2xl space-y-2">
                        {item.points.map((point, j) => (
                          <li
                            key={j}
                            className="flex gap-3 text-[14.5px] leading-relaxed text-ink/80"
                          >
                            <span
                              aria-hidden="true"
                              className="mt-[9px] h-1.5 w-3 shrink-0 rounded-[999px_60%_60%_999px] bg-fern/70"
                            />
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </Reveal>
                </li>
              ))}
            </ol>
          </div>

          {/* Aside */}
          <div className="space-y-6 lg:sticky lg:top-24 lg:self-start">
            <Reveal delay={0.1}>
              <div
                className="paint-dab painted-panel rounded-lg p-6 sm:p-7"
                style={{ "--dab": "#b8a8d0" } as React.CSSProperties}
              >
                <h3 className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.3em] text-lavender">
                  <PaintedIcon icon={GraduationCap} className="text-lavender" />
                  Training
                </h3>
                <ul className="mt-5 space-y-4">
                  {training.map((t) => (
                    <li key={t.name} className="border-b border-cream/8 pb-4 last:border-0 last:pb-0">
                      <p className="text-[14.5px] font-semibold leading-snug text-cream">
                        {t.name}
                      </p>
                      <p className="mt-1 text-[13px] text-ink-dim">
                        {t.org}
                        <span className="mx-2 text-rust" aria-hidden="true">
                          ·
                        </span>
                        <span className="font-mono text-[11px] uppercase tracking-[0.14em]">
                          {t.date}
                        </span>
                      </p>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={0.18}>
              <div
                className="paint-dab painted-panel rounded-lg p-6 sm:p-7"
                style={{ "--dab": "#7ac4ce" } as React.CSSProperties}
              >
                <h3 className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.3em] text-aqua">
                  <PaintedIcon icon={Wrench} className="text-aqua" />
                  Working toolkit
                </h3>
                <div className="mt-5 flex flex-wrap gap-2">
                  {toolkit.map((tool) => (
                    <span
                      key={tool}
                      className="rounded-[6px_4px_7px_3px] border border-cream/12 bg-cream/4 px-3 py-1.5 text-[12.5px] text-ink/85 transition-all duration-300 hover:-translate-y-0.5 hover:border-aqua/40 hover:text-cream"
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
