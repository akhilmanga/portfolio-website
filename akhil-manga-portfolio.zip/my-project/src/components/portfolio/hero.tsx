"use client";

import { motion, useReducedMotion } from "framer-motion";
import { FileText, ChevronDown } from "lucide-react";
import { profile } from "@/lib/data";
import { PaintedVine } from "./painted-vine";
import { PaintButton } from "./paint-button";
import { useResumeViewer } from "./resume-viewer";

const easeOut = [0.21, 0.65, 0.16, 1] as const;

const spores = [
  { left: "13%", top: "28%", size: 5, dur: 7.5, delay: 0 },
  { left: "23%", top: "60%", size: 4, dur: 9, delay: 1.2 },
  { left: "77%", top: "33%", size: 5, dur: 8, delay: 0.6 },
  { left: "86%", top: "57%", size: 4, dur: 6.5, delay: 2 },
  { left: "38%", top: "17%", size: 3, dur: 10, delay: 0.3 },
  { left: "62%", top: "73%", size: 4, dur: 8.5, delay: 1.6 },
];

/* Slow forest leaves drifting down through the hero */
const driftingLeaves = [
  { left: "9%", size: 30, dur: 18, delay: 2.5, drift: 42, color: "#5a6e2e" },
  { left: "56%", size: 24, dur: 22, delay: 7, drift: -34, color: "#8a9a3a" },
  { left: "83%", size: 34, dur: 20, delay: 12, drift: -48, color: "#3a5224" },
];

const DRIFT_LEAF_D =
  "M20 2 C 30 10, 38 22, 34 34 C 30 42, 22 44, 17 42 C 8 38, 4 27, 7 17 C 10 8, 15 4, 20 2 Z";

/* Fireflies glowing near the forest floor */
const fireflies = [
  { left: "21%", bottom: "16%", dur: 5.5, delay: 1.2 },
  { left: "46%", bottom: "28%", dur: 6.8, delay: 2.6 },
  { left: "69%", bottom: "12%", dur: 5.2, delay: 0.7 },
  { left: "88%", bottom: "22%", dur: 7.4, delay: 3.4 },
];

export function Hero() {
  const { openResume } = useResumeViewer();
  const reduce = useReducedMotion();

  return (
    <section
      id="top"
      aria-label="Introduction"
      className="relative flex min-h-svh flex-col overflow-hidden"
    >
      {/* Ambience — deep painted ground */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-canvas-deep via-canvas to-canvas-deep"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(ellipse_75%_55%_at_50%_42%,rgba(138,154,58,0.13),transparent_70%)]"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(ellipse_125%_105%_at_50%_50%,transparent_52%,rgba(8,14,7,0.6)_100%)]"
      />
      <div
        aria-hidden="true"
        className="animate-mist absolute bottom-[16%] left-1/2 h-[30%] w-[64%] -translate-x-1/2 rounded-full bg-aqua/6 blur-[120px]"
      />

      {/* Painted vines growing like threads */}
      <PaintedVine side="left" />
      <PaintedVine side="right" />

      {/* Drifting spores */}
      <div aria-hidden="true" className="absolute inset-0 z-[2]">
        {spores.map((s, i) => (
          <motion.span
            key={i}
            className="absolute rounded-full bg-moss"
            style={{ left: s.left, top: s.top, width: s.size, height: s.size }}
            animate={
              reduce
                ? { opacity: 0.18 }
                : { y: [0, -16, 0], opacity: [0.12, 0.55, 0.12] }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    duration: s.dur,
                    delay: s.delay,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }
            }
          />
        ))}
      </div>

      {/* Forest leaves drifting down */}
      <div aria-hidden="true" className="absolute inset-0 z-[2]">
        {driftingLeaves.map((l, i) => (
          <motion.span
            key={`leaf-${i}`}
            className="absolute -top-14"
            style={{ left: l.left }}
            initial={{ y: -60, opacity: 0, rotate: 0 }}
            animate={
              reduce
                ? { opacity: 0 }
                : {
                    y: [-60, 260, 580, 900, 1240],
                    x: [0, l.drift, -l.drift * 0.7, l.drift * 0.5, 0],
                    rotate: [0, 170, -70, 230, 360],
                    opacity: [0, 0.5, 0.45, 0.4, 0],
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    duration: l.dur,
                    delay: l.delay,
                    repeat: Infinity,
                    repeatDelay: 4,
                    times: [0, 0.25, 0.5, 0.75, 1],
                    ease: "linear",
                  }
            }
          >
            <svg
              width={l.size}
              height={l.size * 1.1}
              viewBox="0 0 40 46"
              fill="none"
              className="drop-shadow-[0_6px_10px_rgba(4,8,3,0.4)]"
            >
              <path d={DRIFT_LEAF_D} fill={l.color} opacity="0.85" />
              <path
                d="M20 6 C 18 16, 17 28, 19 40"
                stroke="#141f10"
                strokeWidth="1.2"
                opacity="0.5"
              />
            </svg>
          </motion.span>
        ))}
      </div>

      {/* Fireflies near the forest floor */}
      <div aria-hidden="true" className="absolute inset-0 z-[2]">
        {fireflies.map((f, i) => (
          <motion.span
            key={`fly-${i}`}
            className="absolute h-1.5 w-1.5 rounded-full bg-haze"
            style={{
              left: f.left,
              bottom: f.bottom,
              boxShadow: "0 0 14px 4px rgba(232, 217, 168, 0.5)",
            }}
            animate={
              reduce
                ? { opacity: 0.25 }
                : {
                    opacity: [0.08, 0.9, 0.15, 0.75, 0.08],
                    y: [0, -16, 5, -10, 0],
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    duration: f.dur,
                    delay: f.delay,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }
            }
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col items-center justify-center px-5 pb-28 pt-32 text-center sm:px-8">
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: easeOut }}
          className="flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.3em] text-haze"
        >
          <span
            aria-hidden="true"
            className="inline-block h-2 w-2 rounded-[60%_40%_55%_45%] bg-rust/90"
          />
          {profile.availability}
        </motion.p>

        {/* Name — each word lifted out of its own masked line */}
        <h1 className="font-painterly mt-6 font-display text-[17vw] font-medium leading-[0.95] tracking-tight text-cream drop-shadow-[0_4px_28px_rgba(6,10,4,0.7)] sm:text-7xl md:text-8xl lg:text-[7.5rem]">
          <span className="inline-block overflow-hidden pb-3 align-bottom">
            <motion.span
              className="inline-block"
              initial={{ y: "115%", rotate: 4 }}
              animate={{ y: 0, rotate: 0 }}
              transition={{ duration: 1, delay: 0.22, ease: [0.22, 1, 0.36, 1] }}
              style={{ transformOrigin: "left bottom" }}
            >
              Akhil&nbsp;
            </motion.span>
          </span>
          <span className="inline-block overflow-hidden pb-3 align-bottom">
            <motion.span
              className="inline-block font-medium italic text-haze"
              initial={{ y: "115%", rotate: -5 }}
              animate={{ y: 0, rotate: 0 }}
              transition={{
                duration: 1,
                delay: 0.36,
                ease: [0.22, 1, 0.36, 1],
              }}
              style={{ transformOrigin: "left bottom" }}
            >
              Manga
            </motion.span>
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.52, ease: easeOut }}
          className="font-painterly mt-6 max-w-2xl font-display text-xl italic leading-snug text-haze/95 sm:text-2xl"
        >
          {profile.heroLine}
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.64, ease: easeOut }}
          className="mt-5 max-w-xl text-[15px] leading-relaxed text-ink/85 sm:text-base"
        >
          {profile.heroSub}
        </motion.p>

        {/* Single CTA — opens the resume inside the site */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.78, ease: easeOut }}
          className="mt-10"
        >
          <PaintButton
            onClick={openResume}
            className="group px-9 py-4 text-base"
            ariaLabel="Open resume"
          >
            <FileText
              className="h-4.5 w-4.5 transition-transform duration-300 group-hover:-rotate-6"
              aria-hidden="true"
            />
            Resume
          </PaintButton>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.a
        href="#about"
        aria-label="Scroll to the About section"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-7 left-1/2 z-10 -translate-x-1/2 text-haze/70 transition-colors hover:text-cream"
      >
        <span className="scroll-cue-dot block">
          <ChevronDown className="h-6 w-6" aria-hidden="true" />
        </span>
      </motion.a>
    </section>
  );
}
