"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import type { LucideIcon } from "lucide-react";

/**
 * A hand-painted icon — springs in like a dab of impasto and its
 * strokes draw themselves, one by one, as though being inked in.
 */
export function PaintedIcon({
  icon: Icon,
  iconClassName = "h-5 w-5",
  className = "",
  delay = 0,
}: {
  icon: LucideIcon;
  iconClassName?: string;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-30px" });

  return (
    <motion.span
      ref={ref}
      aria-hidden="true"
      initial={{ scale: 0.4, rotate: -14, opacity: 0 }}
      animate={
        inView
          ? { scale: 1, rotate: 0, opacity: 1 }
          : { scale: 0.4, rotate: -14, opacity: 0 }
      }
      transition={{ type: "spring", stiffness: 230, damping: 16, delay }}
      className={`icon-draw inline-grid place-items-center ${
        inView ? "icon-draw-run" : ""
      } ${className}`}
    >
      <Icon className={iconClassName} />
    </motion.span>
  );
}
