"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  motion,
  useAnimationControls,
  useInView,
  useMotionValue,
  useReducedMotion,
  useSpring,
} from "framer-motion";

/**
 * AKHIL MANGA — the name painted as an oil-painting centrepiece.
 *
 * A laurel of hand-painted branches arcs over and under the name while
 * a loaded brush drags a swash of green behind the lettering. The name
 * is revealed by a brush-wipe mask, leaves sprout along the branches,
 * loose leaves flutter down through the composition and fireflies drift
 * around it forever.
 *
 * The painting is alive — run your cursor across it and leaves trickle
 * off the brush; click (or press Enter) and the name recoils, branches
 * shudder and a flurry of painted leaves bursts outward.
 */

const VIEW_W = 1200;
const VIEW_H = 505;

/* Branch geometry — an arch over the name, a bowl under it */
const ARCH_D =
  "M 40 250 C 170 96, 420 46, 600 52 C 780 46, 1030 96, 1160 250";
const BOWL_L_D = "M 120 342 C 250 432, 430 458, 600 462";
const BOWL_R_D = "M 1080 342 C 950 432, 770 458, 600 462";

const ARCH_FRACS = [
  0.05, 0.12, 0.2, 0.28, 0.36, 0.44, 0.52, 0.6, 0.68, 0.76, 0.84, 0.92,
];
const BOWL_FRACS = [0.12, 0.28, 0.44, 0.6, 0.76, 0.9];

const LEAF_COLORS = [
  "#2e4a1e",
  "#4a6224",
  "#5a6e2e",
  "#3a5224",
  "#6b7a30",
  "#8a9a3a",
];
const PETAL_COLORS = ["#d8a0c0", "#e8d9a8", "#b8a8d0"];

type LeafT = {
  x: number;
  y: number;
  angle: number;
  side: number;
  len: number;
  wid: number;
  color: string;
  frac: number;
};

function leafPath(len: number, w: number) {
  return `M 0 0 C ${len * 0.28} ${-w}, ${len * 0.78} ${-w * 0.72}, ${len} 0 C ${
    len * 0.78
  } ${w * 0.55}, ${len * 0.28} ${w * 0.66}, 0 0 Z`;
}

/* Loose leaves that flutter down through the composition */
const FALLING_LEAVES = [
  { x: 262, y: 96, dx: -38, rot: 230, color: "#5a6e2e", len: 46 },
  { x: 705, y: 80, dx: 30, rot: -215, color: "#8a9a3a", len: 40 },
  { x: 958, y: 130, dx: -24, rot: 190, color: "#3a5224", len: 44 },
];

/* Fireflies drifting around the name */
const FIREFLIES = [
  { cx: 178, cy: 300, r: 3.8, c: "#e8d9a8", dur: 5.4 },
  { cx: 1032, cy: 316, r: 3.2, c: "#d8a0c0", dur: 6.6 },
  { cx: 600, cy: 116, r: 3.4, c: "#e8d9a8", dur: 5.8 },
  { cx: 318, cy: 90, r: 2.8, c: "#8a9a3a", dur: 7.2 },
  { cx: 906, cy: 94, r: 3.6, c: "#e8d9a8", dur: 6.1 },
  { cx: 468, cy: 428, r: 3, c: "#d8a0c0", dur: 5.6 },
  { cx: 748, cy: 436, r: 2.8, c: "#8a9a3a", dur: 6.9 },
  { cx: 118, cy: 190, r: 3, c: "#e8d9a8", dur: 6.4 },
  { cx: 1082, cy: 178, r: 3.2, c: "#d8a0c0", dur: 5.9 },
  { cx: 600, cy: 350, r: 2.8, c: "#e8d9a8", dur: 7.6 },
];

const EASE_PAINT = [0.65, 0, 0.35, 1] as const;

/* ---- Interaction ---- */

/* hit-box around the lettering (SVG coordinates) */
const NAME_BOX = { x: 110, y: 152, w: 980, h: 142 };
const MAX_PARTICLES = 46;

type Particle = {
  id: number;
  x: number;
  y: number;
  ex: number;
  ey: number;
  midX: number;
  midY: number;
  rot: number;
  len: number;
  color: string;
  dur: number;
  delay: number;
  scale: number;
};

type Ring = {
  id: number;
  x: number;
  y: number;
  base: number;
  scaleTo: number;
  dur: number;
  delay: number;
};

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: readonly T[]): T =>
  arr[Math.floor(Math.random() * arr.length)];

export function OilSignature() {
  const reduce = useReducedMotion();
  const rootRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const inView = useInView(rootRef, { once: true, margin: "-120px" });

  const archRef = useRef<SVGPathElement>(null);
  const bowlLRef = useRef<SVGPathElement>(null);
  const bowlRRef = useRef<SVGPathElement>(null);
  const [archLeaves, setArchLeaves] = useState<LeafT[]>([]);
  const [bowlLeaves, setBowlLeaves] = useState<LeafT[]>([]);

  /* ---- interactive state ---- */
  const [particles, setParticles] = useState<Particle[]>([]);
  const [rings, setRings] = useState<Ring[]>([]);
  const [hoverName, setHoverName] = useState(false);
  const idRef = useRef(0);
  const lastTrickle = useRef(0);
  const lastPt = useRef({ x: -999, y: -999 });

  const archShake = useAnimationControls();
  const bowlShake = useAnimationControls();
  const nameCtrl = useAnimationControls();

  /* leaf-spirit that follows the cursor, with a lagging paint-drop trail */
  const glowX = useMotionValue(-240);
  const glowY = useMotionValue(-240);
  const glowOp = useMotionValue(0);
  const spiritX = useSpring(glowX, { stiffness: 170, damping: 22, mass: 0.7 });
  const spiritY = useSpring(glowY, { stiffness: 170, damping: 22, mass: 0.7 });
  const spiritOp = useSpring(glowOp, { stiffness: 90, damping: 26 });
  const trailX = useSpring(glowX, { stiffness: 55, damping: 17, mass: 1.2 });
  const trailY = useSpring(glowY, { stiffness: 55, damping: 17, mass: 1.2 });

  /* Measure the branches and place leaves along their tangents */
  useEffect(() => {
    const place = (
      el: SVGPathElement | null,
      fracs: number[],
      lenBase: number,
      both: boolean
    ): LeafT[] => {
      if (!el) return [];
      try {
        const total = el.getTotalLength();
        return fracs.map((frac, i) => {
          const p = el.getPointAtLength(total * frac);
          const p2 = el.getPointAtLength(Math.min(total, total * frac + 6));
          const angle = (Math.atan2(p2.y - p.y, p2.x - p.x) * 180) / Math.PI;
          const len = lenBase - Math.abs(0.5 - frac) * 26 + (i % 3) * 5;
          return {
            x: p.x,
            y: p.y,
            angle,
            side: both
              ? i % 2 === 0
                ? 1
                : -1
              : i % 2 === 0
                ? -1
                : 1,
            len,
            wid: len * 0.32,
            color: LEAF_COLORS[(i + (both ? 0 : 2)) % LEAF_COLORS.length],
            frac,
          };
        });
      } catch {
        return [];
      }
    };

    setArchLeaves(place(archRef.current, ARCH_FRACS, 62, true));
    setBowlLeaves([
      ...place(bowlLRef.current, BOWL_FRACS, 54, false),
      ...place(bowlRRef.current, BOWL_FRACS, 54, false),
    ]);
  }, []);

  /* ---- pointer helpers ---- */

  const toSvg = useCallback(
    (clientX: number, clientY: number) => {
      const svg = svgRef.current;
      if (!svg) return null;
      const r = svg.getBoundingClientRect();
      if (r.width === 0) return null;
      return {
        x: ((clientX - r.left) / r.width) * VIEW_W,
        y: ((clientY - r.top) / r.height) * VIEW_H,
      };
    },
    []
  );

  const addParticles = useCallback((next: Particle[]) => {
    setParticles((prev) => {
      const merged = [...prev, ...next];
      return merged.length > MAX_PARTICLES
        ? merged.slice(merged.length - MAX_PARTICLES)
        : merged;
    });
  }, []);

  const removeParticle = useCallback((id: number) => {
    setParticles((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const removeRing = useCallback((id: number) => {
    setRings((prev) => prev.filter((r) => r.id !== id));
  }, []);

  /* A flurry of painted leaves thrown outward from a point, plus two
     expanding brush-flick rings and a shudder through the branches. */
  const burst = useCallback(
    (x: number, y: number) => {
      if (reduce) return;

      const next: Particle[] = [];
      const N = 15;
      for (let i = 0; i < N; i++) {
        const a = (Math.PI * 2 * i) / N + rand(-0.42, 0.42);
        const s = rand(95, 250);
        next.push({
          id: idRef.current++,
          x,
          y,
          ex: Math.cos(a) * s * 1.12,
          ey: Math.sin(a) * s * 0.62 + rand(130, 210),
          midX: Math.cos(a) * s * 0.5,
          midY: -Math.abs(Math.sin(a)) * rand(30, 95) - rand(8, 40),
          rot: rand(-560, 560),
          len: rand(24, 46),
          color: Math.random() < 0.28 ? pick(PETAL_COLORS) : pick(LEAF_COLORS),
          dur: rand(1.25, 2.05),
          delay: rand(0, 0.07),
          scale: rand(0.8, 1.15),
        });
      }
      addParticles(next);

      const rid = idRef.current;
      setRings((prev) => [
        ...prev,
        {
          id: rid,
          x,
          y,
          base: 36,
          scaleTo: rand(2.4, 2.9),
          dur: 0.75,
          delay: 0,
        },
        {
          id: rid + 1,
          x,
          y,
          base: 20,
          scaleTo: rand(1.7, 2),
          dur: 0.95,
          delay: 0.12,
        },
      ]);
      idRef.current += 2;

      archShake.start({
        rotate: [0, -2.4, 1.7, -1, 0.4, 0],
        transition: { duration: 1.15, ease: "easeInOut" },
      });
      bowlShake.start({
        rotate: [0, 1.8, -1.3, 0.7, -0.3, 0],
        transition: { duration: 1.3, ease: "easeInOut", delay: 0.06 },
      });
    },
    [reduce, addParticles, archShake, bowlShake]
  );

  /* The name recoils like canvas being flicked, then settles */
  const bounceName = useCallback(() => {
    if (reduce) return;
    nameCtrl.start({
      y: [0, 12, -16, 0],
      scale: [1, 0.962, 1.024, 1],
      rotate: [0, -1.4, 0.9, 0],
      transition: { duration: 0.9, ease: [0.3, 0, 0.2, 1] },
    });
  }, [reduce, nameCtrl]);

  const onNameEnter = useCallback(() => {
    if (reduce) return;
    setHoverName(true);
    nameCtrl.start({
      y: -9,
      scale: 1.015,
      rotate: -0.4,
      transition: { duration: 0.55, ease: [0.34, 1.3, 0.64, 1] },
    });
  }, [reduce, nameCtrl]);

  const onNameLeave = useCallback(() => {
    setHoverName(false);
    nameCtrl.start({
      y: 0,
      scale: 1,
      rotate: 0,
      transition: { duration: 0.65, ease: "easeOut" },
    });
  }, [nameCtrl]);

  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const p = toSvg(e.clientX, e.clientY);
      if (!p) return;

      glowX.set(p.x);
      glowY.set(p.y);
      glowOp.set(1);

      if (reduce) return;

      /* brushing past the painting knocks a leaf or two loose */
      const now = performance.now();
      const dx = p.x - lastPt.current.x;
      const dy = p.y - lastPt.current.y;
      const dist = Math.hypot(dx, dy);
      if (now - lastTrickle.current > 120 && dist > 9) {
        lastTrickle.current = now;
        const dirX = dist > 0 ? dx / dist : 1;
        const n = dist > 60 ? 2 : 1;
        const next: Particle[] = [];
        for (let i = 0; i < n; i++) {
          const s = rand(35, 110);
          next.push({
            id: idRef.current++,
            x: p.x + rand(-8, 8),
            y: p.y + rand(-6, 6),
            ex: dirX * s * rand(0.4, 1.1) + rand(-40, 40),
            ey: rand(90, 190),
            midX: dirX * s * 0.5,
            midY: -rand(6, 34) - dy * 0.18,
            rot: rand(-420, 420),
            len: rand(18, 34),
            color:
              Math.random() < 0.22 ? pick(PETAL_COLORS) : pick(LEAF_COLORS),
            dur: rand(1.1, 1.8),
            delay: 0,
            scale: rand(0.6, 0.95),
          });
        }
        addParticles(next);
      }
      lastPt.current = { x: p.x, y: p.y };
    },
    [reduce, toSvg, glowX, glowY, glowOp, addParticles]
  );

  const handlePointerLeave = useCallback(() => {
    glowOp.set(0);
    setHoverName(false);
  }, [glowOp]);

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      const p = toSvg(e.clientX, e.clientY) ?? { x: 600, y: 250 };
      burst(p.x, p.y);
      const inName =
        p.x > NAME_BOX.x &&
        p.x < NAME_BOX.x + NAME_BOX.w &&
        p.y > NAME_BOX.y &&
        p.y < NAME_BOX.y + NAME_BOX.h;
      if (inName) bounceName();
    },
    [toSvg, burst, bounceName]
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        burst(600, 255);
        bounceName();
      }
    },
    [burst, bounceName]
  );

  /* Reveal timings */
  const swashW = { duration: 1.05, ease: EASE_PAINT, delay: 0.05 };
  const textW = { duration: 1.25, ease: EASE_PAINT, delay: 0.28 };

  return (
    <div
      ref={rootRef}
      className="relative mx-auto w-full max-w-[1150px] cursor-pointer select-none rounded-2xl outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-8 focus-visible:outline-haze/50"
      role="img"
      aria-label="Akhil Manga — name painted in oil-paint branches and leaves. Click or press Enter to scatter the leaves."
      tabIndex={0}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      <svg
        ref={svgRef}
        viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
        fill="none"
        className="h-auto w-full overflow-visible"
      >
        <defs>
          {/* Lettering gradients */}
          <linearGradient id="sig-gold" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fbf3dd" />
            <stop offset="0.55" stopColor="#f5e6c8" />
            <stop offset="1" stopColor="#e2c98e" />
          </linearGradient>
          <linearGradient id="sig-haze" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f2e6bd" />
            <stop offset="0.5" stopColor="#e8d9a8" />
            <stop offset="1" stopColor="#c9b070" />
          </linearGradient>
          <linearGradient id="sig-swash-grad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#3a5224" />
            <stop offset="0.5" stopColor="#6b7a30" />
            <stop offset="1" stopColor="#3a5224" />
          </linearGradient>
          <radialGradient id="sig-glow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#8a9a3a" stopOpacity="0.16" />
            <stop offset="1" stopColor="#8a9a3a" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="sig-spirit-glow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#e8d9a8" stopOpacity="0.22" />
            <stop offset="0.55" stopColor="#8a9a3a" stopOpacity="0.1" />
            <stop offset="1" stopColor="#8a9a3a" stopOpacity="0" />
          </radialGradient>
          {/* Paint-edge + impasto shadow, tuned for display type */}
          <filter
            id="sig-paint"
            x="-8%"
            y="-25%"
            width="116%"
            height="150%"
          >
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.011 0.018"
              numOctaves="3"
              seed="11"
              result="n"
            />
            <feDisplacementMap
              in="SourceGraphic"
              in2="n"
              scale="7"
              xChannelSelector="R"
              yChannelSelector="G"
              result="d"
            />
            <feDropShadow
              in="d"
              dx="0"
              dy="9"
              stdDeviation="9"
              floodColor="#050a04"
              floodOpacity="0.55"
            />
          </filter>
          {/* Brush-wipe reveal masks */}
          <mask id="sig-swash-mask">
            <motion.rect
              x="40"
              y="110"
              height="230"
              fill="#fff"
              initial={reduce ? { width: 1120 } : { width: 0 }}
              animate={
                inView ? { width: 1120 } : reduce ? { width: 1120 } : { width: 0 }
              }
              transition={reduce ? { duration: 0 } : swashW}
            />
          </mask>
          <mask id="sig-text-mask">
            <motion.rect
              x="110"
              y="110"
              height="210"
              fill="#fff"
              initial={reduce ? { width: 980 } : { width: 0 }}
              animate={
                inView ? { width: 980 } : reduce ? { width: 980 } : { width: 0 }
              }
              transition={reduce ? { duration: 0 } : textW}
            />
          </mask>
        </defs>

        {/* Halo glow breathing behind everything — brightens under the cursor */}
        <motion.g
          initial={{ scale: 1, opacity: 0.88 }}
          animate={{
            scale: hoverName ? 1.07 : 1,
            opacity: hoverName ? 1 : 0.88,
          }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          <motion.ellipse
            cx="600"
            cy="245"
            rx="440"
            ry="150"
            fill="url(#sig-glow)"
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: [0, 1] } : { opacity: 0 }}
            transition={{ duration: 1.6, delay: 0.4 }}
            style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
          />
        </motion.g>

        {/* ---- The arch branch above the name ---- */}
        <motion.g
          animate={archShake}
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          <motion.g
            style={{ transformBox: "fill-box", transformOrigin: "50% 100%" }}
            animate={reduce ? undefined : { rotate: [-0.6, 0.6] }}
            transition={{
              duration: 9,
              repeat: Infinity,
              repeatType: "mirror",
              ease: "easeInOut",
            }}
          >
            {/* invisible measurement path */}
            <path ref={archRef} d={ARCH_D} stroke="none" fill="none" opacity="0" />
            <motion.path
              d={ARCH_D}
              stroke="#3a5224"
              strokeWidth="9"
              strokeLinecap="round"
              initial={reduce ? false : { pathLength: 0 }}
              animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
              transition={
                reduce ? { duration: 0 } : { duration: 1.7, delay: 0.2, ease: EASE_PAINT }
              }
            />
            <motion.path
              d={ARCH_D}
              stroke="#8a9a3a"
              strokeWidth="2.6"
              strokeLinecap="round"
              opacity="0.85"
              initial={reduce ? false : { pathLength: 0 }}
              animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
              transition={
                reduce
                  ? { duration: 0 }
                  : { duration: 1.4, delay: 0.45, ease: EASE_PAINT }
              }
            />
            {/* tendril curls on the arch ends */}
            {[
              "M 40 250 C 26 264, 28 280, 46 282 C 60 284, 64 270, 52 262",
              "M 1160 250 C 1174 264, 1172 280, 1154 282 C 1140 284, 1136 270, 1148 262",
            ].map((d, i) => (
              <motion.path
                key={i}
                d={d}
                stroke="#8a9a3a"
                strokeWidth="2.4"
                strokeLinecap="round"
                initial={reduce ? false : { pathLength: 0, opacity: 0 }}
                animate={
                  inView || reduce ? { pathLength: 1, opacity: 1 } : { pathLength: 0, opacity: 0 }
                }
                transition={
                  reduce
                    ? { duration: 0 }
                    : { duration: 0.9, delay: 1.6 + i * 0.2, ease: "easeOut" }
                }
              />
            ))}

            {/* arch leaves */}
            {archLeaves.map((leaf, i) => (
              <g
                key={`arch-${i}`}
                transform={`translate(${leaf.x} ${leaf.y}) rotate(${
                  leaf.angle + leaf.side * 54
                }) scale(1 ${leaf.side})`}
              >
                <motion.path
                  d={leafPath(leaf.len, leaf.wid)}
                  fill={leaf.color}
                  stroke="#1c2c12"
                  strokeWidth="1.5"
                  initial={reduce ? false : { scale: 0, opacity: 0 }}
                  animate={
                    inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }
                  }
                  transition={
                    reduce
                      ? { duration: 0 }
                      : {
                          delay: 0.55 + leaf.frac * 1.35,
                          type: "spring",
                          stiffness: 160,
                          damping: 13,
                        }
                  }
                  style={{ transformBox: "fill-box", transformOrigin: "0% 50%" }}
                />
              </g>
            ))}

            {/* crown flower at the top of the arch */}
            <motion.g
              transform="translate(600 50)"
              initial={reduce ? false : { scale: 0, opacity: 0 }}
              animate={inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
              transition={
                reduce
                  ? { duration: 0 }
                  : { delay: 1.75, type: "spring", stiffness: 180, damping: 12 }
              }
              style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
            >
              {[0, 72, 144, 216, 288].map((deg) => {
                const a = ((deg - 90) * Math.PI) / 180;
                return (
                  <circle
                    key={deg}
                    cx={Math.cos(a) * 8}
                    cy={Math.sin(a) * 8}
                    r={5.4}
                    fill="#d8a0c0"
                    stroke="#1c2c12"
                    strokeWidth="1"
                  />
                );
              })}
              <circle r={3.6} fill="#f5e6c8" stroke="#1c2c12" strokeWidth="1" />
            </motion.g>
          </motion.g>
        </motion.g>

        {/* ---- The bowl branches under the name ---- */}
        <motion.g
          animate={bowlShake}
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          <motion.g
            style={{ transformBox: "fill-box", transformOrigin: "50% 0%" }}
            animate={reduce ? undefined : { rotate: [0.45, -0.45] }}
            transition={{
              duration: 11,
              repeat: Infinity,
              repeatType: "mirror",
              ease: "easeInOut",
            }}
          >
            <path ref={bowlLRef} d={BOWL_L_D} stroke="none" fill="none" opacity="0" />
            <path ref={bowlRRef} d={BOWL_R_D} stroke="none" fill="none" opacity="0" />
            {[BOWL_L_D, BOWL_R_D].map((d, i) => (
              <g key={i}>
                <motion.path
                  d={d}
                  stroke="#3a5224"
                  strokeWidth="8"
                  strokeLinecap="round"
                  initial={reduce ? false : { pathLength: 0 }}
                  animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
                  transition={
                    reduce
                      ? { duration: 0 }
                      : { duration: 1.5, delay: 0.5 + i * 0.15, ease: EASE_PAINT }
                  }
                />
                <motion.path
                  d={d}
                  stroke="#8a9a3a"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  opacity="0.8"
                  initial={reduce ? false : { pathLength: 0 }}
                  animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
                  transition={
                    reduce
                      ? { duration: 0 }
                      : { duration: 1.25, delay: 0.7 + i * 0.15, ease: EASE_PAINT }
                  }
                />
              </g>
            ))}

            {/* bowl leaves */}
            {bowlLeaves.map((leaf, i) => (
              <g
                key={`bowl-${i}`}
                transform={`translate(${leaf.x} ${leaf.y}) rotate(${
                  leaf.angle + leaf.side * 56
                }) scale(1 ${leaf.side})`}
              >
                <motion.path
                  d={leafPath(leaf.len, leaf.wid)}
                  fill={leaf.color}
                  stroke="#1c2c12"
                  strokeWidth="1.4"
                  initial={reduce ? false : { scale: 0, opacity: 0 }}
                  animate={
                    inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }
                  }
                  transition={
                    reduce
                      ? { duration: 0 }
                      : {
                          delay: 0.85 + leaf.frac * 1.15,
                          type: "spring",
                          stiffness: 150,
                          damping: 13,
                        }
                  }
                  style={{ transformBox: "fill-box", transformOrigin: "0% 50%" }}
                />
              </g>
            ))}

            {/* flower cluster where the bowls meet */}
            {[
              { x: 600, y: 462, c: "#d8a0c0", s: 1 },
              { x: 574, y: 456, c: "#b8a8d0", s: 0.72 },
              { x: 626, y: 456, c: "#e8d9a8", s: 0.66 },
            ].map((f, i) => (
              <motion.g
                key={`bowl-flower-${i}`}
                transform={`translate(${f.x} ${f.y}) scale(${f.s})`}
                initial={reduce ? false : { scale: 0, opacity: 0 }}
                animate={inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
                transition={
                  reduce
                    ? { duration: 0 }
                    : {
                        delay: 1.9 + i * 0.16,
                        type: "spring",
                        stiffness: 170,
                        damping: 12,
                      }
                }
                style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
              >
                {[0, 72, 144, 216, 288].map((deg) => {
                  const a = ((deg - 90) * Math.PI) / 180;
                  return (
                    <circle
                      key={deg}
                      cx={Math.cos(a) * 7.5}
                      cy={Math.sin(a) * 7.5}
                      r={5}
                      fill={f.c}
                      stroke="#1c2c12"
                      strokeWidth="1"
                    />
                  );
                })}
                <circle r={3.2} fill="#f5e6c8" stroke="#1c2c12" strokeWidth="1" />
              </motion.g>
            ))}
          </motion.g>
        </motion.g>

        {/* ---- Loose leaves fluttering down (behind the lettering) ---- */}
        {FALLING_LEAVES.map((leaf, i) => (
          <motion.g
            key={`fall-${i}`}
            transform={`translate(${leaf.x} ${leaf.y})`}
            initial={{ opacity: 0 }}
            animate={
              reduce || !inView
                ? { opacity: 0 }
                : {
                    opacity: [0, 0.9, 0.8, 0],
                    y: [0, 110, 240, 380],
                    x: [0, leaf.dx * 0.6, -leaf.dx * 0.4, leaf.dx],
                    rotate: [0, leaf.rot * 0.4, -leaf.rot * 0.2, leaf.rot],
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    duration: 4.6,
                    delay: 2.5 + i * 0.95,
                    times: [0, 0.32, 0.66, 1],
                    repeat: Infinity,
                    repeatDelay: 7.5 + i,
                    ease: "linear",
                  }
            }
            style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
          >
            <path
              d={leafPath(leaf.len, leaf.len * 0.34)}
              fill={leaf.color}
              stroke="#1c2c12"
              strokeWidth="1.3"
              opacity="0.9"
            />
          </motion.g>
        ))}

        {/* ---- Brush swash — an under-swipe dragged beneath the lettering.
                It stretches a touch when the name is hovered ---- */}
        <motion.g
          animate={{
            scaleX: hoverName ? 1.025 : 1,
            scaleY: hoverName ? 1.08 : 1,
          }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          <motion.path
            d="M 70 284 C 320 272, 520 292, 600 290 C 680 292, 880 272, 1130 284 C 880 314, 680 324, 600 322 C 520 324, 320 314, 70 284 Z"
            fill="url(#sig-swash-grad)"
            opacity="0.58"
            filter="url(#rough-edge)"
            mask="url(#sig-swash-mask)"
          />
        </motion.g>

        {/* ---- The name (lifts on hover, recoils on click) ---- */}
        <motion.g
          animate={nameCtrl}
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          <g mask="url(#sig-text-mask)">
            {/* impasto ghost — a second loaded pass slightly offset */}
            <text
              x="602.5"
              y="272"
              textAnchor="middle"
              textLength="950"
              lengthAdjust="spacing"
              fill="#2e4a1e"
              opacity="0.3"
              fontFamily="var(--font-fraunces), Georgia, 'Times New Roman', serif"
              fontWeight={600}
              fontSize="126"
            >
              <tspan>AKHIL</tspan>
              <tspan fontStyle="italic"> MANGA</tspan>
            </text>
            {/* main pass */}
            <text
              x="600"
              y="268"
              textAnchor="middle"
              textLength="950"
              lengthAdjust="spacing"
              filter="url(#sig-paint)"
              fontFamily="var(--font-fraunces), Georgia, 'Times New Roman', serif"
              fontWeight={600}
              fontSize="126"
            >
              <tspan fill="url(#sig-gold)">AKHIL</tspan>
              <tspan fill="url(#sig-haze)" fontStyle="italic">
                {" "}
                MANGA
              </tspan>
            </text>
          </g>
        </motion.g>

        {/* invisible hit-box over the lettering for hover / click intents */}
        <rect
          x={NAME_BOX.x}
          y={NAME_BOX.y}
          width={NAME_BOX.w}
          height={NAME_BOX.h}
          fill="transparent"
          style={{ pointerEvents: "all", cursor: "pointer" }}
          onPointerEnter={onNameEnter}
          onPointerLeave={onNameLeave}
        />

        {/* ---- Thrown leaves + expanding brush-flick rings ---- */}
        {rings.map((r) => (
          <g key={`ring-${r.id}`} transform={`translate(${r.x} ${r.y})`}>
            <motion.g
              initial={{ scale: 0.25, opacity: 0.75 }}
              animate={{ scale: r.scaleTo, opacity: 0 }}
              transition={{
                duration: r.dur,
                delay: r.delay,
                ease: [0.16, 1, 0.3, 1],
              }}
              onAnimationComplete={() => removeRing(r.id)}
              style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
            >
              <circle
                r={r.base}
                fill="none"
                stroke="#e8d9a8"
                strokeWidth="2"
                strokeDasharray="2 8"
                strokeLinecap="round"
                opacity="0.85"
              />
            </motion.g>
          </g>
        ))}
        {particles.map((p) => (
          <g key={`p-${p.id}`} transform={`translate(${p.x} ${p.y})`}>
            <motion.g
              initial={{ x: 0, y: 0, rotate: 0, opacity: 0, scale: p.scale }}
              animate={{
                x: [0, p.midX, p.ex * 0.8, p.ex],
                y: [0, p.midY, p.ey * 0.62, p.ey],
                rotate: [0, p.rot * 0.28, p.rot * 0.72, p.rot],
                opacity: [0, 1, 0.92, 0],
                scale: p.scale,
              }}
              transition={{
                duration: p.dur,
                delay: p.delay,
                times: [0, 0.34, 0.72, 1],
                ease: "easeOut",
              }}
              onAnimationComplete={() => removeParticle(p.id)}
              style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
            >
              <path
                d={leafPath(p.len, p.len * 0.34)}
                fill={p.color}
                stroke="#1c2c12"
                strokeWidth="1.2"
              />
            </motion.g>
          </g>
        ))}

        {/* ---- Fireflies ---- */}
        {FIREFLIES.map((f, i) => (
          <motion.g
            key={`fly-${i}`}
            transform={`translate(${f.cx} ${f.cy})`}
            initial={{ opacity: 0 }}
            animate={
              reduce || !inView
                ? { opacity: 0.35 }
                : {
                    opacity: [0.08, 0.9, 0.15, 0.7, 0.08],
                    y: [0, -13, 4, -8, 0],
                    x: [0, 5, -4, 3, 0],
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    duration: f.dur,
                    delay: 1.6 + i * 0.7,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }
            }
          >
            <circle
              r={f.r * 3.4}
              fill={f.c}
              opacity="0.22"
              style={{ filter: "blur(5px)" }}
            />
            <circle r={f.r} fill={f.c} />
          </motion.g>
        ))}

        {/* ---- Ground brush strokes at the very bottom ---- */}
        {[
          {
            d: "M 120 486 C 350 476, 700 494, 1080 482",
            w: 7,
            c: "#1c2c12",
            o: 0.6,
          },
          {
            d: "M 200 494 C 480 486, 760 500, 1010 490",
            w: 3.5,
            c: "#22361a",
            o: 0.45,
          },
        ].map((s, i) => (
          <motion.path
            key={`ground-${i}`}
            d={s.d}
            stroke={s.c}
            strokeWidth={s.w}
            strokeLinecap="round"
            opacity={s.o}
            initial={reduce ? false : { pathLength: 0 }}
            animate={inView || reduce ? { pathLength: 1 } : { pathLength: 0 }}
            transition={
              reduce
                ? { duration: 0 }
                : { duration: 1.6, delay: 1.9 + i * 0.25, ease: EASE_PAINT }
            }
          />
        ))}

        {/* small flower anchoring the ground stroke's right end */}
        <motion.g
          transform="translate(1088 480) scale(0.72)"
          initial={reduce ? false : { scale: 0, opacity: 0 }}
          animate={inView || reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
          transition={
            reduce
              ? { duration: 0 }
              : { delay: 2.6, type: "spring", stiffness: 170, damping: 12 }
          }
          style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
        >
          {[0, 72, 144, 216, 288].map((deg) => {
            const a = ((deg - 90) * Math.PI) / 180;
            return (
              <circle
                key={deg}
                cx={Math.cos(a) * 7.5}
                cy={Math.sin(a) * 7.5}
                r={5}
                fill="#b8a8d0"
                stroke="#141f10"
                strokeWidth="1"
              />
            );
          })}
          <circle r={3.2} fill="#f5e6c8" stroke="#141f10" strokeWidth="1" />
        </motion.g>

        {/* ---- The leaf-spirit that rides the cursor ---- */}
        <motion.g
          style={{
            x: trailX,
            y: trailY,
            opacity: spiritOp,
            pointerEvents: "none",
          }}
        >
          <circle r="7" fill="#d8a0c0" opacity="0.55" />
          <circle r="13" fill="#d8a0c0" opacity="0.16" />
        </motion.g>
        <motion.g
          style={{
            x: spiritX,
            y: spiritY,
            opacity: spiritOp,
            pointerEvents: "none",
          }}
        >
          <circle r="54" fill="url(#sig-spirit-glow)" />
          <motion.g
            animate={reduce ? undefined : { rotate: 360 }}
            transition={{ duration: 13, repeat: Infinity, ease: "linear" }}
            style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
          >
            <path
              d={leafPath(16, 5.4)}
              fill="#8a9a3a"
              stroke="#1c2c12"
              strokeWidth="1"
              opacity="0.95"
            />
          </motion.g>
          <circle r="2.2" fill="#fbf3dd" />
        </motion.g>
      </svg>
    </div>
  );
}
