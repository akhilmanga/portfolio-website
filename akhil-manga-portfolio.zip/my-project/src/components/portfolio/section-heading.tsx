"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Section heading — a sprouting leaf paints the eyebrow in, the
 * title rises out of a masked line like a brush-lift off the canvas,
 * and the brush underline finishes with a leaf unfurling at its tip.
 */
export function SectionHeading({
  index,
  eyebrow,
  title,
  lead,
  align = "left",
  className = "",
}: {
  index: string;
  eyebrow: string;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  const centered = align === "center";
  return (
    <div
      className={`${centered ? "mx-auto text-center" : ""} max-w-3xl ${className}`}
    >
      {/* Eyebrow with a sprouting leaf */}
      <motion.p
        initial={{ opacity: 0, y: 14 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.6, ease: [0.21, 0.65, 0.16, 1] }}
        className={`flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.35em] text-moss ${
          centered ? "justify-center" : ""
        }`}
      >
        <motion.svg
          viewBox="0 0 24 30"
          className="h-[22px] w-[19px] shrink-0 text-moss"
          aria-hidden="true"
          initial="hidden"
          whileInView="shown"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.path
            d="M12 28 C 12 21, 12 15, 12 5"
            stroke="currentColor"
            strokeWidth="2.6"
            strokeLinecap="round"
            fill="none"
            variants={{
              hidden: { pathLength: 0 },
              shown: {
                pathLength: 1,
                transition: { duration: 0.7, ease: [0.6, 0, 0.3, 1] },
              },
            }}
          />
          <motion.path
            d="M12 18 C 7 16, 4.4 11.5, 4 6.5 C 9.2 8.6, 11.6 12.6, 12 18 Z"
            fill="currentColor"
            variants={{
              hidden: { scale: 0, opacity: 0 },
              shown: {
                scale: 1,
                opacity: 1,
                transition: {
                  delay: 0.38,
                  type: "spring",
                  stiffness: 210,
                  damping: 13,
                },
              },
            }}
            style={{ transformBox: "fill-box", transformOrigin: "70% 85%" }}
          />
          <motion.path
            d="M12 13.5 C 16 11.5, 18.6 7.6, 19 3.4 C 14.2 5.4, 12.3 9.2, 12 13.5 Z"
            fill="#5a6e2e"
            variants={{
              hidden: { scale: 0, opacity: 0 },
              shown: {
                scale: 1,
                opacity: 1,
                transition: {
                  delay: 0.52,
                  type: "spring",
                  stiffness: 210,
                  damping: 13,
                },
              },
            }}
            style={{ transformBox: "fill-box", transformOrigin: "30% 85%" }}
          />
        </motion.svg>
        <span>
          {index} <span className="text-ink-dim">/</span> {eyebrow}
        </span>
      </motion.p>

      {/* Title rising out of a masked line */}
      <div className="-mt-1 overflow-hidden pb-2 pt-1">
        <motion.h2
          initial={{ y: "112%", rotate: 2.5, opacity: 0.4 }}
          whileInView={{ y: 0, rotate: 0, opacity: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{
            duration: 0.95,
            delay: 0.08,
            ease: [0.22, 1, 0.36, 1],
          }}
          style={{ transformOrigin: "left bottom" }}
          className="font-painterly font-display text-4xl font-medium leading-[1.06] tracking-tight text-cream sm:text-5xl"
        >
          {title}
        </motion.h2>
      </div>

      {/* Brush underline, finished with a leaf at its tip */}
      <motion.svg
        aria-hidden="true"
        viewBox="0 0 240 14"
        fill="none"
        className={`mt-4 h-3.5 w-44 text-rust ${centered ? "mx-auto" : ""}`}
        initial="hidden"
        whileInView="shown"
        viewport={{ once: true, margin: "-60px" }}
      >
        <motion.path
          d="M4 9 C 56 3, 108 13, 152 7 C 186 3, 214 10, 236 5"
          stroke="currentColor"
          strokeWidth="5"
          strokeLinecap="round"
          variants={{
            hidden: { pathLength: 0, opacity: 0.4 },
            shown: {
              pathLength: 1,
              opacity: 0.9,
              transition: {
                duration: 1.1,
                delay: 0.3,
                ease: [0.6, 0, 0.3, 1],
              },
            },
          }}
        />
        <motion.path
          d="M18 6 C 70 12, 130 4, 228 8"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          opacity="0.45"
          variants={{
            hidden: { pathLength: 0 },
            shown: {
              pathLength: 1,
              transition: {
                duration: 1.2,
                delay: 0.55,
                ease: [0.6, 0, 0.3, 1],
              },
            },
          }}
        />
        <motion.path
          d="M30 11 C 90 14, 160 8, 226 11"
          stroke="#8a9a3a"
          strokeWidth="1.4"
          strokeLinecap="round"
          variants={{
            hidden: { pathLength: 0, opacity: 0 },
            shown: {
              pathLength: 1,
              opacity: 0.55,
              transition: {
                duration: 1.2,
                delay: 0.7,
                ease: [0.6, 0, 0.3, 1],
              },
            },
          }}
        />
        {/* the tip leaf unfurls last */}
        <motion.path
          d="M0 0 C 7 -5, 15 -5, 19 0 C 15 4.5, 7 4.5, 0 0 Z"
          fill="#8a9a3a"
          transform="translate(226 5) rotate(-24)"
          variants={{
            hidden: { scale: 0, opacity: 0 },
            shown: {
              scale: 1,
              opacity: 0.9,
              transition: {
                delay: 1.45,
                type: "spring",
                stiffness: 240,
                damping: 12,
              },
            },
          }}
          style={{ transformBox: "fill-box", transformOrigin: "0% 50%" }}
        />
      </motion.svg>

      {lead ? (
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{
            duration: 0.7,
            delay: 0.18,
            ease: [0.21, 0.65, 0.16, 1],
          }}
          className="mt-6 max-w-2xl text-[17px] leading-relaxed text-ink-dim sm:text-lg"
        >
          {lead}
        </motion.p>
      ) : null}
    </div>
  );
}
