import fs from "fs";
import path from "path";
import { Download } from "lucide-react";

/**
 * A small floating pill that lets the site owner grab the full source
 * bundle straight from the running site.
 *
 * Self-hiding: it only renders while `public/akhil-manga-portfolio.zip`
 * actually exists on disk — so on a public deployment (where the zip is
 * not shipped) the button simply never appears.
 */
export function DownloadCode() {
  let zipPresent = false;
  try {
    zipPresent = fs.existsSync(
      path.join(process.cwd(), "public", "akhil-manga-portfolio.zip")
    );
  } catch {
    zipPresent = false;
  }

  if (!zipPresent) return null;

  return (
    <a
      href="/akhil-manga-portfolio.zip"
      download="akhil-manga-portfolio.zip"
      aria-label="Download the complete source code as a zip file"
      title="Download the complete source code"
      className="btn-paint inline-flex items-center gap-2.5 px-5 py-2.5 text-[13px] font-semibold tracking-tight text-canvas-deep"
      style={{
        position: "fixed",
        bottom: "calc(1.25rem + env(safe-area-inset-bottom))",
        right: "1.25rem",
        zIndex: 70,
      }}
    >
      <span className="btn-paint-bg" aria-hidden="true" />
      <Download className="h-4 w-4" aria-hidden="true" />
      Source code
    </a>
  );
}
