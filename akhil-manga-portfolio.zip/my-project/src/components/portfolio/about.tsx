"use client";

import { Compass } from "lucide-react";
import { profile, stats } from "@/lib/data";
import { SectionHeading } from "./section-heading";
import { Counter } from "./counter";
import { PaintedIcon } from "./painted-icon";
import { Reveal } from "./reveal";

export function About() {
  return (
    <section
      id="about"
      aria-label="About"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-start gap-14 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
          {/* Text */}
          <div>
            <SectionHeading
              index="01"
              eyebrow="About"
              title={
                <>
                  A generalist with{" "}
                  <span className="italic text-haze">deep roots</span>.
                </>
              }
            />

            <div className="mt-8 max-w-2xl space-y-5 text-[16px] leading-relaxed text-ink/85 sm:text-[17px]">
              {profile.summary.map((paragraph, i) => (
                <Reveal key={i} delay={0.08 * i}>
                  <p className={i === 0 ? "text-cream/95" : undefined}>
                    {paragraph}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Now */}
          <Reveal delay={0.15} className="lg:sticky lg:top-24">
            <div
              className="paint-dab painted-panel painted-panel-warm hover-lift rounded-lg p-6 sm:p-7"
              style={{ "--dab": "#c4523f" } as React.CSSProperties}
            >
              <p className="flex items-start gap-3.5 text-[15px] leading-relaxed text-cream/90 sm:text-base">
                <PaintedIcon
                  icon={Compass}
                  className="mt-1 shrink-0 text-sienna"
                  delay={0.2}
                />
                {profile.nowLine}
              </p>
            </div>
          </Reveal>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4">
          {stats.map((stat, i) => (
            <Reveal key={stat.label} delay={0.08 * i}>
              <div
                className="paint-dab painted-panel hover-lift rounded-lg p-5 sm:p-6"
                style={{ "--dab": stat.dab } as React.CSSProperties}
              >
                <p className="font-painterly font-display text-3xl font-semibold text-cream sm:text-4xl">
                  <Counter
                    value={stat.value}
                    prefix={"prefix" in stat ? stat.prefix : ""}
                    suffix={stat.suffix}
                  />
                </p>
                <p className="mt-2 text-[13px] leading-snug text-ink-dim">
                  {stat.label}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
