"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, Download, ExternalLink, FileText } from "lucide-react";

const RESUME_SRC = "/resume.pdf";

const ResumeCtx = createContext<{ openResume: () => void }>({
  openResume: () => {},
});

export function useResumeViewer() {
  return useContext(ResumeCtx);
}

export function ResumeViewerProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  const openResume = useCallback(() => setOpen(true), []);
  const close = useCallback(() => {
    setOpen(false);
    setLoaded(false);
  }, []);

  /* Escape to close, scroll lock, focus the close button,
     and a grace-period fallback for PDF onload events. */
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const t = setTimeout(() => setLoaded(true), 2800);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
      clearTimeout(t);
    };
  }, [open, close]);

  return (
    <ResumeCtx.Provider value={{ openResume }}>
      {children}
      <AnimatePresence>
        {open ? (
          <motion.div
            key="resume-viewer"
            role="dialog"
            aria-modal="true"
            aria-label="Resume viewer"
            className="fixed inset-0 z-[90] flex items-center justify-center p-3 sm:p-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Backdrop */}
            <motion.button
              type="button"
              aria-label="Close resume viewer"
              onClick={close}
              className="absolute inset-0 cursor-zoom-out bg-canvas-deep/85 backdrop-blur-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            {/* Panel — the canvas being hung on the wall */}
            <motion.div
              className="paint-dab relative flex h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-cream/15 bg-[#141f10] shadow-[0_40px_120px_rgba(3,7,2,0.75)]"
              style={{ "--dab": "#8a9a3a" } as React.CSSProperties}
              initial={{ opacity: 0, y: 70, scale: 0.93, rotate: -0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1, rotate: 0 }}
              exit={{
                opacity: 0,
                y: 50,
                scale: 0.95,
                rotate: 0.6,
                transition: { duration: 0.28 },
              }}
              transition={{ type: "spring", stiffness: 160, damping: 22 }}
            >
              {/* Header */}
              <div className="relative flex items-center justify-between gap-3 border-b border-cream/10 px-4 py-3.5 sm:px-7 sm:py-4">
                <div className="min-w-0">
                  <motion.p
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.22, duration: 0.4 }}
                    className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-moss"
                  >
                    <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                    Resume
                  </motion.p>
                  <motion.p
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.32, duration: 0.45 }}
                    className="font-painterly-gentle mt-1 truncate font-display text-lg italic leading-tight text-cream sm:text-xl"
                  >
                    Akhil M · AI Generalist &amp; Field-Builder
                  </motion.p>
                  <motion.svg
                    aria-hidden="true"
                    viewBox="0 0 200 8"
                    fill="none"
                    className="mt-1.5 h-1.5 w-32 text-rust"
                  >
                    <motion.path
                      d="M3 5 C 48 2, 96 7, 132 4 C 158 2, 178 6, 197 3"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                      initial={{ pathLength: 0, opacity: 0 }}
                      animate={{ pathLength: 1, opacity: 0.85 }}
                      transition={{ delay: 0.5, duration: 0.8, ease: [0.6, 0, 0.3, 1] }}
                    />
                  </motion.svg>
                </div>

                <motion.div
                  className="flex shrink-0 items-center gap-2"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.4 }}
                >
                  <a
                    href={RESUME_SRC}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-md border border-cream/15 px-3 py-2 text-[12px] font-medium text-ink transition-colors hover:border-cream/35 hover:text-cream"
                  >
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="hidden sm:inline">New tab</span>
                  </a>
                  <a
                    href={RESUME_SRC}
                    download
                    className="inline-flex items-center gap-1.5 rounded-md border border-cream/15 px-3 py-2 text-[12px] font-medium text-ink transition-colors hover:border-cream/35 hover:text-cream"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="hidden sm:inline">Download</span>
                  </a>
                  <button
                    ref={closeRef}
                    type="button"
                    onClick={close}
                    aria-label="Close resume viewer"
                    className="grid h-9 w-9 place-items-center rounded-md border border-cream/15 text-ink transition-all hover:border-rust/60 hover:bg-rust/15 hover:text-cream focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-moss"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </button>
                </motion.div>
              </div>

              {/* Body */}
              <div className="relative flex-1 bg-[#0d150a]">
                <iframe
                  src={`${RESUME_SRC}#view=FitH`}
                  title="Akhil Manga — Resume (PDF)"
                  className="h-full w-full"
                  onLoad={() => setLoaded(true)}
                />

                {/* Loading — a brushstroke sweeping the canvas */}
                <AnimatePresence>
                  {!loaded ? (
                    <motion.div
                      key="loader"
                      className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-6 bg-[#0d150a]"
                      initial={{ opacity: 1 }}
                      exit={{ opacity: 0, transition: { duration: 0.5 } }}
                    >
                      <div className="relative h-2 w-56 overflow-hidden rounded-full bg-cream/8">
                        <motion.div
                          className="absolute inset-y-0 w-1/3 rounded-full bg-gradient-to-r from-transparent via-moss to-transparent"
                          initial={{ x: "-120%" }}
                          animate={{ x: "340%" }}
                          transition={{
                            duration: 1.4,
                            repeat: Infinity,
                            ease: "easeInOut",
                          }}
                        />
                      </div>
                      <p className="font-mono text-[10px] uppercase tracking-[0.32em] text-ink-dim">
                        Unrolling the canvas
                      </p>
                    </motion.div>
                  ) : null}
                </AnimatePresence>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </ResumeCtx.Provider>
  );
}
