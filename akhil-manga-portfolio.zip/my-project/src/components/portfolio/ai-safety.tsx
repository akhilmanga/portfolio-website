"use client";

import { ArrowUpRight, Compass, Route, Users, Sprout } from "lucide-react";
import { focusRoles, fellowships, aiSafetyCards } from "@/lib/data";
import { SectionHeading } from "./section-heading";
import { PaintedIcon } from "./painted-icon";
import { Reveal } from "./reveal";

const roleIcons = [Compass, Route, Users];
const roleDabs = ["#8a9a3a", "#7ac4ce", "#d8a0c0"];

export function AiSafety() {
  return (
    <section
      id="ai-safety"
      aria-label="AI safety"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          index="04"
          eyebrow="AI Safety"
          title={
            <>
              The work that matters{" "}
              <span className="italic text-haze">most now</span>.
            </>
          }
          lead="Looking for full-time opportunities at AI safety orgs"
        />

        {/* Focus roles */}
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {focusRoles.map((focus, i) => {
            const Icon = roleIcons[i];
            return (
              <Reveal key={focus.role} delay={0.07 * i}>
                <div
                  className="paint-dab painted-panel hover-lift h-full rounded-lg p-6"
                  style={{ "--dab": roleDabs[i] } as React.CSSProperties}
                >
                  <span className="grid h-11 w-11 place-items-center rounded-[10px_6px_12px_5px] border border-cream/12 bg-cream/5 text-haze">
                    <PaintedIcon
                      icon={Icon}
                      className="text-haze"
                      delay={0.12 * i}
                    />
                  </span>
                  <h3 className="mt-4 font-display text-xl font-semibold tracking-tight text-cream">
                    {focus.role}
                  </h3>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-ink/80">
                    {focus.detail}
                  </p>
                </div>
              </Reveal>
            );
          })}
        </div>

        {/* Cards */}
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {aiSafetyCards.map((card, i) => (
            <Reveal key={card.title} delay={0.06 * i}>
              <a
                href={card.url ?? undefined}
                {...(card.url
                  ? { target: "_blank", rel: "noopener noreferrer" }
                  : {})}
                className={`paint-dab painted-panel hover-lift group flex h-full flex-col rounded-lg p-6 sm:p-7 ${
                  card.url ? "" : "cursor-default"
                }`}
                style={
                  {
                    "--dab":
                      i % 3 === 0
                        ? "#7ac4ce"
                        : i % 3 === 1
                          ? "#8a9a3a"
                          : "#b8a8d0",
                  } as React.CSSProperties
                }
              >
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ink-dim">
                  {card.org}
                </p>
                <h3 className="mt-3 flex items-start justify-between gap-3 font-display text-[22px] font-semibold leading-tight tracking-tight text-cream">
                  {card.title}
                  {card.url ? (
                    <ArrowUpRight
                      className="mt-1 h-4.5 w-4.5 shrink-0 text-ink-dim/50 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-cream"
                      aria-hidden="true"
                    />
                  ) : (
                    <Sprout
                      className="mt-1 h-4.5 w-4.5 shrink-0 text-moss/70"
                      aria-hidden="true"
                    />
                  )}
                </h3>
                <p className="mt-2.5 text-[14px] leading-relaxed text-ink/80">
                  {card.detail}
                </p>
              </a>
            </Reveal>
          ))}
        </div>

        {/* Fellowships */}
        <Reveal delay={0.15}>
          <div className="mt-10 flex flex-wrap items-center gap-x-4 gap-y-3 rounded-lg border border-dashed border-cream/15 bg-canvas/40 px-6 py-5">
            <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-ink-dim">
              Fellowships of interest
            </p>
            <div className="flex flex-wrap gap-2" aria-label="Fellowships of interest">
              {fellowships.map((fellowship) => (
                <span
                  key={fellowship}
                  className="font-painterly-gentle rounded-[6px_4px_7px_3px] border border-moss/30 bg-moss/10 px-3.5 py-1.5 font-display text-[15px] font-semibold italic tracking-tight text-haze"
                >
                  {fellowship}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
