"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";

/**
 * A hand-painted vine that grows like a thread up the side of
 * the hero — stem strokes draw themselves in, leaves sprout with
 * springs, petals pop, and the whole vine sways gently forever.
 */

const STEM_D =
  "M 70 940 C 96 812, 44 730, 98 648 C 152 566, 72 486, 122 404 C 172 322, 108 246, 158 176 C 188 132, 208 110, 232 66";

const LEAF_FRACS = [
  0.05, 0.13, 0.21, 0.29, 0.37, 0.45, 0.53, 0.61, 0.69, 0.77, 0.85, 0.92,
];

const LEAF_COLORS = [
  "#2e4a1e",
  "#4a6224",
  "#5a6e2e",
  "#3a5224",
  "#6b7a30",
  "#8a9a3a",
];

type LeafT = {
  x: number;
  y: number;
  angle: number;
  side: number;
  len: number;
  wid: number;
  color: string;
  frac: number;
};

type FlowerT = { x: number; y: number; color: string; delay: number };

function leafPath(len: number, w: number) {
  return `M 0 0 C ${len * 0.28} ${-w}, ${len * 0.78} ${-w * 0.72}, ${len} 0 C ${
    len * 0.78
  } ${w * 0.55}, ${len * 0.28} ${w * 0.66}, 0 0 Z`;
}

export function PaintedVine({ side }: { side: "left" | "right" }) {
  const reduce = useReducedMotion();
  const stemRef = useRef<SVGPathElement>(null);
  const [leaves, setLeaves] = useState<LeafT[]>([]);
  const [flowers, setFlowers] = useState<FlowerT[]>([]);

  /* Measure the stem and place leaves along it, alternating sides,
     each rotated to follow the local tangent of the thread. */
  useEffect(() => {
    const el = stemRef.current;
    if (!el) return;
    try {
      const total = el.getTotalLength();
      const ls: LeafT[] = LEAF_FRACS.map((frac, i) => {
        const p = el.getPointAtLength(total * frac);
        const p2 = el.getPointAtLength(
          Math.min(total, total * frac + 6)
        );
        const angle =
          (Math.atan2(p2.y - p.y, p2.x - p.x) * 180) / Math.PI;
        const len = 80 - Math.abs(0.5 - frac) * 34 + (i % 3) * 6;
        return {
          x: p.x,
          y: p.y,
          angle,
          side: i % 2 === 0 ? 1 : -1,
          len,
          wid: len * 0.3,
          color: LEAF_COLORS[i % LEAF_COLORS.length],
          frac,
        };
      });
      setLeaves(ls);

      const fs: FlowerT[] = [0.34, 0.78].map((frac, i) => {
        const p = el.getPointAtLength(total * frac);
        return {
          x: p.x,
          y: p.y,
          color: i === 0 ? "#d8a0c0" : "#b8a8d0",
          delay: 1.7 + i * 0.45,
        };
      });
      setFlowers(fs);
    } catch {
      /* measurement unavailable — stem still renders */
    }
  }, []);

  const stemTransition = reduce
    ? { duration: 0 }
    : { duration: 2.6, ease: [0.65, 0, 0.35, 1] as const };

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute bottom-0 z-[1] aspect-[420/940] h-[60vh] w-auto sm:h-[78vh] ${
        side === "left" ? "left-[-20px] sm:left-2" : "right-[-20px] sm:right-2"
      }`}
      style={side === "right" ? { transform: "scaleX(-1)" } : undefined}
    >
      <motion.div
        className="h-full w-full"
        style={{ transformOrigin: "50% 100%" }}
        animate={reduce ? undefined : { rotate: [-0.9, 0.9] }}
        transition={
          reduce
            ? undefined
            : {
                duration: 7.5,
                repeat: Infinity,
                repeatType: "mirror",
                ease: "easeInOut",
              }
        }
      >
        <svg
          viewBox="0 0 420 940"
          fill="none"
          className="h-full w-full overflow-visible drop-shadow-[0_10px_18px_rgba(4,8,3,0.45)]"
        >
          {/* rough painted edges on everything below */}
          <g filter="url(#rough-edge)">
          {/* invisible measurement path */}
          <path
            ref={stemRef}
            d={STEM_D}
            stroke="none"
            fill="none"
            opacity="0"
          />

          {/* stem base — dark olive */}
          <motion.path
            d={STEM_D}
            stroke="#3a5224"
            strokeWidth="8"
            strokeLinecap="round"
            initial={reduce ? false : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={stemTransition}
          />
          {/* stem highlight — moss thread */}
          <motion.path
            d={STEM_D}
            stroke="#8a9a3a"
            strokeWidth="2.5"
            strokeLinecap="round"
            opacity="0.85"
            initial={reduce ? false : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={
              reduce
                ? { duration: 0 }
                : { duration: 2.2, delay: 0.25, ease: [0.65, 0, 0.35, 1] as const }
            }
          />
          {/* tendril curl at the tip */}
          <motion.path
            d="M 232 66 C 250 48, 270 52, 264 72 C 260 86, 244 84, 246 70"
            stroke="#8a9a3a"
            strokeWidth="2.5"
            strokeLinecap="round"
            initial={reduce ? false : { pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={
              reduce
                ? { duration: 0 }
                : { duration: 1, delay: 2.35, ease: "easeOut" }
            }
          />

          {/* leaves */}
          {leaves.map((leaf, i) => (
            <g
              key={i}
              filter="url(#leaf-edge)"
              transform={`translate(${leaf.x} ${leaf.y}) rotate(${
                leaf.angle + leaf.side * 46
              }) scale(1 ${leaf.side})`}
            >
              <motion.g
                style={{
                  transformBox: "fill-box",
                  transformOrigin: "0% 50%",
                }}
                initial={reduce ? false : { scale: 0, rotate: -24, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                transition={
                  reduce
                    ? { duration: 0 }
                    : {
                        delay: 0.45 + leaf.frac * 2.1,
                        type: "spring",
                        stiffness: 150,
                        damping: 13,
                      }
                }
              >
                <path
                  d={leafPath(leaf.len, leaf.wid)}
                  fill={leaf.color}
                  stroke="#1c2c12"
                  strokeWidth="1.6"
                />
                <path
                  d={`M 3 0 Q ${leaf.len * 0.5} ${-leaf.wid * 0.22} ${
                    leaf.len * 0.88
                  } 0`}
                  stroke="#1c2c12"
                  strokeWidth="1.1"
                  opacity="0.55"
                />
              </motion.g>
            </g>
          ))}

          {/* impasto flowers */}
          {flowers.map((f, i) => (
            <g key={`flower-${i}`} transform={`translate(${f.x} ${f.y})`}>
              <motion.g
                style={{
                  transformBox: "fill-box",
                  transformOrigin: "50% 50%",
                }}
                initial={reduce ? false : { scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={
                  reduce
                    ? { duration: 0 }
                    : { delay: f.delay, type: "spring", stiffness: 170, damping: 12 }
                }
              >
                {Array.from({ length: 5 }).map((_, k) => {
                  const a = ((k * 72 - 90) * Math.PI) / 180;
                  return (
                    <circle
                      key={k}
                      cx={Math.cos(a) * 7.5}
                      cy={Math.sin(a) * 7.5}
                      r={5}
                      fill={f.color}
                      stroke="#1c2c12"
                      strokeWidth="1"
                    />
                  );
                })}
                <circle r={3.4} fill="#f5e6c8" stroke="#1c2c12" strokeWidth="1" />
              </motion.g>
            </g>
          ))}
          </g>
        </svg>
      </motion.div>
    </div>
  );
}
