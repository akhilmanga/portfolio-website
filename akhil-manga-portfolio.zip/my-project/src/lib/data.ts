export const profile = {
  name: "Akhil Manga",
  initials: "AM",
  role: "AI Safety — Operations, Programs & Community",
  location: "Hyderabad, India",
  email: "akhilmanga1234@proton.me",
  timezone: "IST (UTC+5:30)",
  availability: "Open to AI safety roles & fellowships",
  heroLine:
    "Building the field where humanity meets its most powerful technology.",
  heroSub:
    "Technical generalist with deep roots in Web3 security research, program operations and community building — now fully focused on AI safety.",
  summary: [
    "I'm a technical generalist transitioning into AI safety, with deep roots in Web3 security research, program operations, community building, and 0→1 product development.",
    "Trained by BlueDot Impact in Technical AI Safety and AGI Strategy, I'm currently building an AI-safety field-building project that solves talent and coordination problems and improves the workflow of AI researchers.",
    "I work well with technical researchers — designing programs, building systems, and using AI tools to turn ambiguous problems into shipped solutions.",
  ],
  nowLine:
    "Currently: building an AI-safety field-building project, and looking for Operations Generalist, Program Coordinator and Community Manager roles in AI safety — plus fellowships.",
  resumeFile: "/resume.pdf",
  projectsUrl:
    "https://app.notion.com/p/Projects-Web3-AI-384d4fe1d840802783f6f7e8d5dff03f",
  linktreeUrl: "https://linktr.ee/akhilmanga",
};

export const socials = [
  { label: "X (Twitter)", handle: "@akhil_manga", url: "https://x.com/akhil_manga", icon: "twitter" },
  { label: "LinkedIn", handle: "in/akhilmanga", url: "https://www.linkedin.com/in/akhilmanga/", icon: "linkedin" },
  { label: "GitHub", handle: "akhilmanga", url: "https://github.com/akhilmanga", icon: "github" },
  { label: "Telegram", handle: "@akhilmanga", url: "https://t.me/akhilmanga", icon: "send" },
  { label: "Linktree", handle: "linktr.ee/akhilmanga", url: "https://linktr.ee/akhilmanga", icon: "link" },
  { label: "Email", handle: "akhilmanga1234@proton.me", url: "mailto:akhilmanga1234@proton.me", icon: "mail" },
] as const;

export const stats = [
  { value: 1000, suffix: "+", label: "Community members grown from zero", dab: "#8a9a3a" },
  { value: 41, suffix: "", label: "Chapters in the AI Safety Handbook", dab: "#7ac4ce" },
  { value: 9, suffix: "", label: "Audit stacks covered at Cobra Audits", dab: "#c4523f" },
  { value: 4000, prefix: "$", label: "Grant initiative delivered end-to-end", dab: "#b8a8d0" },
] as const;

/* ---------------- Experience ---------------- */

export type ExperienceItem = {
  role: string;
  org: string;
  period: string;
  points: string[];
  url?: string;
};

export const experience: ExperienceItem[] = [
  {
    role: "Founder",
    org: "Defenders Den",
    period: "Aug 2023 — Present",
    points: [
      "Organically grew a technical security community from 0 to 1,000+ members",
      "Built systems for onboarding, technical education, researcher collaboration and team formation",
      "Created 2–4 person security research teams across L1/L2, DEXs, lending, NFT and ZK protocols",
      "Led end-to-end delivery of a $4,000 grant-funded security education initiative",
      "Partnered with Cyfrin Updraft, Alchemy University, KOLs and security protocols; ran workshops, AMAs and learning pipelines",
    ],
    url: "https://defendersden.framer.website/",
  },
  {
    role: "Head of Community",
    org: "Lore Network",
    period: "Dec 2024 — Mar 2025",
    points: [
      "Owned community for an AI-powered proof-of-learning protocol",
      "Designed onboarding & feedback systems that shaped product iteration",
      "Coordinated engineering ↔ community communication; ran growth and engagement campaigns",
      "Led in-person workshops as part of GTM strategy",
    ],
  },
  {
    role: "Founding Member & Product Strategist",
    org: "Cicada",
    period: "Apr 2024 — Present",
    points: [
      "Interviewed security researchers to map workflows, pain points and product requirements for a gamified auditing platform",
      "Built contributor feedback loops connecting researchers and community to product development",
      "Contributed to 0→1 product strategy and experimentation",
    ],
  },
  {
    role: "Volunteer Lead",
    org: "Devconnect",
    period: "Nov 2025 · Buenos Aires",
    points: [
      "Led and coordinated a volunteer team supporting a large international Ethereum ecosystem event",
      "Coordinated people, logistics and on-ground execution across a distributed volunteer operation",
    ],
  },
  {
    role: "N&W S4 Builder",
    org: "Buildspace (YC & a16z backed)",
    period: "Aug 2023 — Sep 2023",
    points: [
      "Selected for a 6-week 0→1 building program",
      "Shipped a self-directed project from idea to initial users; 3-day IRL builder experience in Dubai",
    ],
  },
];

export const training = [
  { name: "Web3 Degree, Blockchain Technology", org: "Alchemy University", date: "Nov 2022" },
  { name: "Security & Auditing", org: "Cyfrin Updraft", date: "Dec 2023" },
  { name: "DevRel Uni — Cohort 5", org: "DevRel Uni", date: "May 2024" },
];

export const toolkit = [
  "Codex",
  "Claude",
  "Google AI Studio",
  "NotebookLM",
  "Notion",
  "Discord",
  "Telegram",
  "Framer",
];

/* ---------------- Security research ---------------- */

export const cobra = {
  name: "Cobra Audits",
  line: "Private Web3 security audits",
  detail:
    "Independent security reviews for protocols that cannot afford critical failures — full proofs of concept, severity-based reports, and remediation support.",
  stacks: [
    "Solidity",
    "Rust",
    "ZK",
    "Cairo",
    "Go",
    "Move",
    "Circom",
    "Noir",
    "L1 / Bridges",
  ],
  process: ["Detect", "Prove", "Classify", "Report", "Remediate"],
  url: "https://cobraaudits.netlify.app/",
  reportUrl: "https://app.notion.com/p/Cobra-Audits-37bf44dc679a80229a9ffc201ee30e91",
};

export const auditRecord = [
  {
    platform: "Code4rena",
    highlight: "4th place — Intuition",
    detail: "11th place — Chainlink Payment Abstraction V2 · 2 Medium findings · $340+ earned",
    url: "https://code4rena.com/@akhilmanga",
  },
  {
    platform: "Sherlock",
    highlight: "Top-10 contest finish",
    detail: "4 Medium findings · $359 earned as a Watson",
    url: "https://audits.sherlock.xyz/watson/akhilmanga",
  },
  {
    platform: "Hackenproof",
    highlight: "First Blood",
    detail: "Paid High-severity report · member since Mar 2026",
    url: "https://hackenproof.com/hackers/akhilmanga",
  },
  {
    platform: "Cantina",
    highlight: "2 accepted findings",
    detail: "Revert Finance StableSwap Hooks and more",
    url: "https://cantina.xyz/u/akhilmanga",
  },
  {
    platform: "CodeHawks",
    highlight: "First contest: Jul 2023",
    detail: "Foundry DeFi Stablecoin (#68) · Escrow (#94) — incl. a Chainlink minAnswer finding",
    url: "https://codehawks.com/",
  },
];

export const openSource = [
  {
    title: "leanVM Contributor",
    org: "leanEthereum",
    detail:
      "Contributor to leanVM — a minimal hash-based zkVM for post-quantum Ethereum, end-to-end formally verified in Lean 4.",
    url: "https://github.com/leanEthereum/leanVM/graphs/contributors",
  },
  {
    title: "Audit Portfolio",
    org: "GitHub",
    detail:
      "Public PDF audit reports: PasswordStore, PuppyRaffle, TSwap, TunderLoan, BossBridge and more.",
    url: "https://github.com/akhilmanga/Audit-Portfolio",
  },
];

/* ---------------- AI safety ---------------- */

export const focusRoles = [
  {
    role: "Operations Generalist",
    detail:
      "Wearing every hat an AI safety org needs — programs, logistics, coordination and whatever unblocks the mission this week.",
  },
  {
    role: "Program Coordinator",
    detail:
      "Designing and running fellowships, courses and research programs end-to-end, from cohort design to outcomes.",
  },
  {
    role: "Community Manager",
    detail:
      "Growing technical communities that actually ship — onboarding systems, feedback loops, and 1,000+ member proof.",
  },
];

export const fellowships = ["MATS", "SPAR", "PIVOTAL", "ERA", "GENERATOR RESIDENCY"];

export const aiSafetyCards = [
  {
    title: "Technical AI Safety",
    org: "BlueDot Impact · Feb 2026",
    detail:
      "Alignment, evaluations, interpretability, AI control and scalable oversight — certified.",
    url: "https://bluedot.org/certification?id=reclvNJnsimUAHBKV",
  },
  {
    title: "AGI Strategy",
    org: "BlueDot Impact · Aug 2026",
    detail: "AI progress, threat pathways, and defense in depth for the road to AGI.",
  },
  {
    title: "AI Safety Handbook",
    org: "aisafetyhandbook.netlify.app",
    detail:
      "A complete field guide to AI safety — 8 parts, 41 chapters, 3 appendices — written for newcomers and career-changers.",
    url: "https://aisafetyhandbook.netlify.app/",
  },
  {
    title: "AI Economics Manifesto",
    org: "X · @akhil_manga",
    detail:
      "An essay on the economics of the intelligence age — who captures the value, and what it means for the future.",
    url: "https://x.com/akhil_manga/status/2087555349096398945",
  },
  {
    title: "Intro to Effective Altruism",
    org: "Effective Altruism",
    detail:
      "Cause prioritization, global impact assessment and evidence-based decision-making.",
    url: "https://x.com/akhil_manga/status/2120789079608758628",
  },
];

/* ---------------- Projects ---------------- */

export const projectsBlurb = {
  heading: "The rest of the work lives in one place",
  copy: "Security tools, AI-powered products, community platforms, DeFi experiments — I keep the full project log on a single Notion page: what was built, why, and what it does.",
  cta: "Open the project log",
  note: "Selected public work — Cobra Audits, the AI Safety Handbook, Defenders Den — is linked in the sections above.",
};

/* ---------------- Nav ---------------- */

export const navLinks = [
  { label: "About", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Security", href: "#security" },
  { label: "AI Safety", href: "#ai-safety" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];
