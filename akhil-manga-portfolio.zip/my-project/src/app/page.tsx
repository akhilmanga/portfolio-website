import { Nav } from "@/components/portfolio/nav";
import { Hero } from "@/components/portfolio/hero";
import { About } from "@/components/portfolio/about";
import { Experience } from "@/components/portfolio/experience";
import { Security } from "@/components/portfolio/security";
import { AiSafety } from "@/components/portfolio/ai-safety";
import { Projects } from "@/components/portfolio/projects";
import { Contact } from "@/components/portfolio/contact";
import { Footer } from "@/components/portfolio/footer";
import { BranchDivider } from "@/components/portfolio/branch-divider";
import { PaintFilters } from "@/components/portfolio/paint-filters";
import { ResumeViewerProvider } from "@/components/portfolio/resume-viewer";
import { DownloadCode } from "@/components/portfolio/download-code";

export default function Home() {
  return (
    <ResumeViewerProvider>
      <div className="flex min-h-screen flex-col">
        <PaintFilters />
        <Nav />
        <main className="flex-1">
          <Hero />
          <About />
          <BranchDivider tone="fern" />
          <Experience />
          <BranchDivider tone="rust" />
          <Security />
          <BranchDivider tone="aqua" />
          <AiSafety />
          <BranchDivider tone="fern" />
          <Projects />
          <BranchDivider tone="rust" />
          <Contact />
        </main>
        <Footer />
        <DownloadCode />
      </div>
    </ResumeViewerProvider>
  );
}
