import type { Metadata, Viewport } from "next";
import { Geist, JetBrains_Mono, Fraunces } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const fraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  style: ["normal", "italic"],
  axes: ["SOFT", "WONK", "opsz"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"
  ),
  title: "Akhil Manga — AI Safety Operations, Programs & Community",
  description:
    "Portfolio of Akhil Manga — a technical generalist now fully focused on AI safety. Previously Web3 security research (Cobra Audits), program operations and community building.",
  keywords: [
    "Akhil Manga",
    "AI Safety",
    "Operations Generalist",
    "Program Coordinator",
    "Community Manager",
    "Web3 Security",
    "Cobra Audits",
    "AI Safety Handbook",
    "Defenders Den",
  ],
  authors: [{ name: "Akhil Manga" }],
  icons: {
    icon: "/am.svg",
  },
  openGraph: {
    title: "Akhil Manga — AI Safety Operations, Programs & Community",
    description:
      "Technical generalist now fully focused on AI safety — operations, programs and community. Previously Web3 security research.",
    url: "/",
    siteName: "Akhil Manga",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "Akhil Manga — AI Safety Operations, Programs & Community",
    description:
      "Technical generalist now fully focused on AI safety — operations, programs and community.",
  },
};

export const viewport: Viewport = {
  themeColor: "#101b0e",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${fraunces.variable} ${jetbrainsMono.variable} font-sans antialiased bg-canvas text-ink`}
      >
        {children}
        <Toaster />
        <div className="paint-surface" aria-hidden="true" />
        <div className="grain" aria-hidden="true" />
      </body>
    </html>
  );
}
