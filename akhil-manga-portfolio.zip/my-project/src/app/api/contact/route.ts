import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const contactSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(120),
  email: z.string().trim().email("A valid email is required").max(200),
  org: z.string().trim().max(160).optional().or(z.literal("")),
  interest: z.string().trim().min(2).max(60).default("general"),
  message: z
    .string()
    .trim()
    .min(10, "Message must be at least 10 characters")
    .max(4000),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const parsed = contactSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          success: false,
          error: "Validation failed",
          issues: parsed.error.issues.map((i) => ({
            field: i.path.join("."),
            message: i.message,
          })),
        },
        { status: 400 }
      );
    }

    const { name, email, org, interest, message } = parsed.data;

    const saved = await db.contactMessage.create({
      data: {
        name,
        email,
        org: org && org.length > 0 ? org : null,
        interest,
        message,
      },
      select: { id: true, createdAt: true },
    });

    return NextResponse.json(
      {
        success: true,
        id: saved.id,
        receivedAt: saved.createdAt,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("[api/contact] Failed to save message:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 }
    );
  }
}
